import { useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { supabaseConfigured } from "../lib/supabase";
import { BagIcon, MenuIcon, SearchIcon, UserIcon } from "./Icons";

const NAV = [["Relógios", "relogios"], ["Semijoias", "semijoias"], ["Colares", "colares-e-correntes"], ["Pulseiras", "pulseiras"], ["Anéis", "aneis"], ["Brincos", "brincos"], ["Acessórios", "acessorios"]];

export default function Layout() {
  const { user, isStaff, signOut } = useAuth();
  const { count } = useCart();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [searching, setSearching] = useState(false);
  const nav = useNavigate();
  return (
    <>
      <a className="skip" href="#main">Pular para o conteúdo</a>
      <div className="topbar">VELLIOR — Elegância em cada detalhe.</div>
      <header className="header">
        <div className="container row">
          <button className="iconbtn burger" aria-label="Abrir menu" aria-expanded={open} onClick={() => setOpen(!open)}><MenuIcon /></button>
          <Link to="/" className="logo" aria-label="VELLIOR — início">VELLIOR</Link>
          <nav className={`nav ${open ? "open" : ""}`} aria-label="Categorias" onClick={() => setOpen(false)}>
            {NAV.map(([n, s]) => <NavLink key={s} to={`/loja?categoria=${s}`}>{n}</NavLink>)}
            <NavLink to="/loja?ofertas=1">Ofertas</NavLink>
          </nav>
          <div className="icons">
            <button className="iconbtn" aria-label="Buscar" onClick={() => setSearching(!searching)}><SearchIcon /></button>
            <Link className="iconbtn" to={user ? "/conta" : "/entrar"} aria-label={user ? "Minha conta" : "Entrar"}><UserIcon /></Link>
            <Link className="iconbtn" to="/carrinho" aria-label={`Carrinho, ${count} itens`}><BagIcon />{count > 0 && <span className="badge">{count}</span>}</Link>
          </div>
        </div>
        {searching && (
          <form className="container" style={{ paddingBottom: 12 }} role="search" onSubmit={(e) => { e.preventDefault(); nav(`/loja?q=${encodeURIComponent(q.trim())}`); setSearching(false); }}>
            <label className="sr-only" htmlFor="q">Buscar produtos</label>
            <input id="q" autoFocus maxLength={80} placeholder="Buscar produtos" value={q} onChange={(e) => setQ(e.target.value)} />
          </form>
        )}
      </header>
      {!supabaseConfigured && <div className="container"><div className="notice error">Supabase não configurado. Defina VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY (veja docs/SETUP.md). A loja não exibirá dados reais até lá.</div></div>}
      <main id="main"><Outlet /></main>
      <footer className="footer">
        <div className="container">
          <div className="cols">
            <div><div className="logo" style={{ fontSize: "1.5rem" }}>VELLIOR</div><p className="muted small">Relógios, semijoias e acessórios.<br />Elegância em cada detalhe.</p></div>
            <div><strong>Loja</strong>{NAV.slice(0, 4).map(([n, s]) => <Link key={s} to={`/loja?categoria=${s}`}>{n}</Link>)}</div>
            <div><strong>Conta</strong><Link to="/conta">Minha conta</Link><Link to="/conta/pedidos">Meus pedidos</Link>{isStaff && <Link to="/admin">Painel administrativo</Link>}{user && <a href="#sair" onClick={(e) => { e.preventDefault(); void signOut(); }}>Sair</a>}</div>
            <div><strong>Institucional</strong><Link to="/termos">Termos de uso</Link><Link to="/privacidade">Política de privacidade</Link><Link to="/cookies">Política de cookies</Link></div>
          </div>
          <p className="muted small" style={{ marginTop: 32 }}>© {new Date().getFullYear()} VELLIOR. Todos os direitos reservados.</p>
        </div>
      </footer>
    </>
  );
}
