import { Link } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { formatBRL } from "../lib/money";

export type ProductRow = {
  id: string; slug: string; name: string; price_cents: number; sale_price_cents: number | null; is_demo: boolean;
  product_images?: { path: string; alt: string | null; position: number }[];
  product_variants?: { stock: number; reserved: number; active: boolean }[];
};
export const imageUrl = (path: string) => supabase.storage.from("product-images").getPublicUrl(path).data.publicUrl;

export function ProductCard({ p }: { p: ProductRow }) {
  const img = [...(p.product_images ?? [])].sort((a, b) => a.position - b.position)[0];
  const available = (p.product_variants ?? []).some((v) => v.active && v.stock - v.reserved > 0);
  return (
    <Link to={`/produto/${p.slug}`} className="pcard">
      <div className="img">{img ? <img src={imageUrl(img.path)} alt={img.alt ?? p.name} loading="lazy" /> : <span className="small">Sem foto</span>}</div>
      <h3>{p.name}</h3>
      <div>
        {p.sale_price_cents != null ? <><span className="old">{formatBRL(p.price_cents)}</span><span className="price">{formatBRL(p.sale_price_cents)}</span></> : <span className="price">{formatBRL(p.price_cents)}</span>}
      </div>
      <div style={{ marginTop: 6, display: "flex", gap: 6 }}>
        {p.is_demo && <span className="tag demo">Demonstração</span>}
        {!available && <span className="tag out">Indisponível</span>}
      </div>
    </Link>
  );
}
