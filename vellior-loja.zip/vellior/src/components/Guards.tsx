import { Navigate, useLocation } from "react-router-dom";
import type { ReactNode } from "react";
import { useAuth } from "../context/AuthContext";

export const Spinner = () => <div className="spinner" role="status" aria-label="Carregando" />;

// A UI apenas melhora a experiência. A autorização real é imposta pelo banco (RLS/RPC) e pelas Edge Functions.
export function RequireAuth({ children }: { children: ReactNode }) {
  const { user, loading } = useAuth();
  const loc = useLocation();
  if (loading) return <Spinner />;
  if (!user) return <Navigate to={`/entrar?next=${encodeURIComponent(loc.pathname + loc.search)}`} replace />;
  return <>{children}</>;
}

export function RequireStaff({ children }: { children: ReactNode }) {
  const { user, isStaff, loading, roles } = useAuth();
  if (loading || (user && roles.length === 0)) return <Spinner />;
  if (!user) return <Navigate to="/entrar?next=/admin" replace />;
  if (!isStaff) return <Navigate to="/" replace />;   // sem pista sobre a existência da área
  return <>{children}</>;
}
