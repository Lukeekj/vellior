import { useEffect, useRef, useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useAsync } from "../hooks/useAsync";
import { useCart } from "../context/CartContext";
import { addressSchema } from "../lib/validation";
import { formatBRL } from "../lib/money";
import { Spinner } from "../components/Guards";
import { useSeo } from "../hooks/useSeo";

type Addr = { id: string; recipient: string; zip: string; street: string; number: string; city: string; state: string; district: string };
type Quote = { subtotal_cents: number; discount_cents: number; shipping_cents: number; total_cents: number; coupon_error: string | null; lines: { available: boolean; product_name: string; variant_label: string; quantity: number; unit_cents: number }[] };
const CERR: Record<string, string> = { invalid: "Cupom inválido.", expired: "Cupom expirado.", exhausted: "Cupom esgotado.", min_subtotal: "Valor mínimo não atingido.", not_applicable: "Cupom não se aplica aos itens." };
const ERRS: Record<string, string> = { out_of_stock: "Um dos itens ficou sem estoque. Revise o carrinho.", empty_cart: "Seu carrinho está vazio.", rate_limited: "Muitas tentativas. Tente mais tarde.", invalid_address: "Endereço inválido." };

export function Checkout() {
  useSeo("Checkout — VELLIOR");
  const nav = useNavigate(); const { reload } = useCart();
  const [addrId, setAddrId] = useState(""); const [coupon, setCoupon] = useState(""); const [applied, setApplied] = useState("");
  const [method, setMethod] = useState<"pix" | "">(""); const [busy, setBusy] = useState(false); const [err, setErr] = useState("");
  const [newAddr, setNewAddr] = useState(false); const [aerr, setAerr] = useState<Record<string, string>>({});
  const [form, setForm] = useState({ recipient: "", zip: "", street: "", number: "", complement: "", district: "", city: "", state: "" });
  const idem = useRef(sessionStorage.getItem("vellior.idem") ?? crypto.randomUUID());
  useEffect(() => { sessionStorage.setItem("vellior.idem", idem.current); }, []);

  const addrs = useAsync(async () => ((await supabase.from("addresses").select("*").order("created_at")).data ?? []) as Addr[]);
  const quote = useAsync(async () => { const { data, error } = await supabase.rpc("quote_cart", { p_coupon: applied || null }); if (error) throw new Error("Não foi possível calcular o pedido."); return data as Quote; }, [applied]);
  const methods = useAsync(async () => ((await supabase.from("payment_methods_config").select("method,enabled")).data ?? []) as { method: string; enabled: boolean }[]);
  useEffect(() => { if (!addrId && addrs.data?.length) setAddrId(addrs.data[0].id); }, [addrs.data, addrId]);
  useEffect(() => { if (methods.data?.find((m) => m.method === "pix" && m.enabled)) setMethod("pix"); }, [methods.data]);

  async function saveAddr(e: FormEvent) {
    e.preventDefault();
    const r = addressSchema.safeParse(form);
    if (!r.success) { setAerr(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message]))); return; }
    const { data: u } = await supabase.auth.getUser();
    const { data, error } = await supabase.from("addresses").insert({ ...r.data, complement: r.data.complement || null, user_id: u.user!.id }).select("id").single();
    if (error) { setErr("Não foi possível salvar o endereço."); return; }
    setAerr({}); setNewAddr(false); await addrs.reload(); setAddrId(data.id);
  }

  async function pay() {
    setErr(""); if (!addrId) { setErr("Selecione um endereço."); return; } if (!method) { setErr("Nenhum método de pagamento disponível."); return; }
    setBusy(true);
    try {
      const { data: orderId, error } = await supabase.rpc("create_order", { p_address_id: addrId, p_coupon: applied || null, p_idempotency_key: idem.current });
      if (error) { const k = Object.keys(ERRS).find((x) => error.message.includes(x)); setErr(k ? ERRS[k] : error.message.includes("coupon_") ? "Cupom não pôde ser aplicado." : "Não foi possível criar o pedido."); return; }
      const { data, error: fe } = await supabase.functions.invoke("create-payment", { body: { method, order_id: orderId } });
      sessionStorage.removeItem("vellior.idem");
      await reload();
      if (fe || data?.error) { nav(`/conta/pedidos/${orderId}?pagamento=erro`); return; }
      nav(`/conta/pedidos/${orderId}`);
    } finally { setBusy(false); }
  }

  if (quote.loading || addrs.loading) return <Spinner />;
  const q = quote.data;
  if (!q || q.lines.length === 0) return <div className="container empty"><h1>Carrinho vazio</h1><Link className="btn" to="/loja">Ver produtos</Link></div>;
  const unavailable = q.lines.some((l) => !l.available);
  const pixOn = methods.data?.some((m) => m.method === "pix" && m.enabled);
  const set = (k: string) => (e: { target: { value: string } }) => setForm({ ...form, [k]: e.target.value });
  return (
    <div className="container section">
      <h1>Finalizar compra</h1>
      <div className="two" style={{ alignItems: "start" }}>
        <div>
          <section className="card" aria-labelledby="s-addr"><h2 id="s-addr" style={{ fontSize: "1.4rem" }}>1. Endereço de entrega</h2>
            {(addrs.data ?? []).map((a) => <label key={a.id} style={{ display: "block", marginBottom: 8 }}><input type="radio" name="addr" checked={addrId === a.id} onChange={() => setAddrId(a.id)} /> {a.recipient} — {a.street}, {a.number}, {a.district}, {a.city}/{a.state}, CEP {a.zip}</label>)}
            {!newAddr ? <button className="btn ghost sm" onClick={() => setNewAddr(true)}>Novo endereço</button> :
              <form onSubmit={saveAddr} noValidate>
                {([["recipient", "Destinatário"], ["zip", "CEP"], ["street", "Rua"], ["number", "Número"], ["complement", "Complemento"], ["district", "Bairro"], ["city", "Cidade"], ["state", "UF"]] as const).map(([k, l]) =>
                  <div className="field" key={k}><label htmlFor={`a-${k}`}>{l}</label><input id={`a-${k}`} value={form[k]} onChange={set(k)} maxLength={k === "state" ? 2 : 160} />{aerr[k] && <span className="err" role="alert">{aerr[k]}</span>}</div>)}
                <button className="btn sm">Salvar endereço</button></form>}
          </section>
          <section className="card" style={{ marginTop: 16 }} aria-labelledby="s-pay"><h2 id="s-pay" style={{ fontSize: "1.4rem" }}>2. Pagamento</h2>
            {pixOn ? <label><input type="radio" checked readOnly /> Pix</label> : <div className="notice">Pagamentos ainda não habilitados nesta loja. Configure em Admin → Pagamentos.</div>}
            <p className="small muted">Cartão de crédito: backend pronto, interface ainda não disponível.</p>
          </section>
        </div>
        <aside className="card" aria-labelledby="s-sum"><h2 id="s-sum" style={{ fontSize: "1.4rem" }}>Resumo</h2>
          {q.lines.map((l, i) => <div key={i} className="row-between small"><span>{l.quantity}× {l.product_name} ({l.variant_label})</span><span>{formatBRL(l.unit_cents * l.quantity)}</span></div>)}
          <hr />
          <form className="row-between" style={{ alignItems: "flex-end" }} onSubmit={(e) => { e.preventDefault(); setApplied(coupon.trim().toUpperCase()); }}>
            <div className="field" style={{ margin: 0, flex: 1 }}><label htmlFor="cup">Cupom</label><input id="cup" value={coupon} maxLength={40} onChange={(e) => setCoupon(e.target.value)} /></div><button className="btn ghost sm">Aplicar</button></form>
          {q.coupon_error && <p className="err" role="alert">{CERR[q.coupon_error] ?? "Cupom inválido."}</p>}
          <div className="row-between"><span>Subtotal</span><span>{formatBRL(q.subtotal_cents)}</span></div>
          {q.discount_cents > 0 && <div className="row-between"><span>Desconto</span><span>− {formatBRL(q.discount_cents)}</span></div>}
          <div className="row-between"><span>Frete</span><span>{q.shipping_cents ? formatBRL(q.shipping_cents) : "Grátis / a definir"}</span></div>
          <div className="row-between" style={{ fontSize: "1.25rem", marginTop: 8 }}><strong>Total</strong><strong>{formatBRL(q.total_cents)}</strong></div>
          {unavailable && <div className="notice error">Há itens indisponíveis. <Link to="/carrinho">Revise o carrinho</Link>.</div>}
          {err && <div className="notice error" role="alert">{err}</div>}
          <button className="btn" style={{ width: "100%", marginTop: 12 }} disabled={busy || unavailable || !pixOn} onClick={pay}>{busy ? "Processando…" : "Pagar com Pix"}</button>
        </aside>
      </div>
    </div>
  );
}
