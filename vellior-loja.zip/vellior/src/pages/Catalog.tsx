import { useSearchParams } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useAsync } from "../hooks/useAsync";
import { ProductCard, type ProductRow } from "../components/ProductCard";
import { Spinner } from "../components/Guards";
import { useSeo } from "../hooks/useSeo";

const PAGE = 12;
const SEL = "id,slug,name,price_cents,sale_price_cents,is_demo,category_id,categories(slug),product_images(path,alt,position),product_variants(stock,reserved,active,color)";

export default function Catalog() {
  useSeo("Loja — VELLIOR");
  const [sp, setSp] = useSearchParams();
  const categoria = sp.get("categoria") ?? "";
  const q = (sp.get("q") ?? "").slice(0, 80);
  const ofertas = sp.get("ofertas") === "1";
  const ordem = sp.get("ordem") ?? "novidades";
  const min = Number(sp.get("min") ?? "") || 0;
  const max = Number(sp.get("max") ?? "") || 0;
  const disp = sp.get("disp") === "1";
  const page = Math.max(1, Number(sp.get("p") ?? "1") || 1);

  const cats = useAsync(async () => (await supabase.from("categories").select("slug,name").order("position")).data ?? []);
  const res = useAsync(async () => {
    let query = supabase.from("products").select(SEL, { count: "exact" });
    if (categoria) { const { data: c } = await supabase.from("categories").select("id").eq("slug", categoria).maybeSingle(); if (!c) return { rows: [] as ProductRow[], total: 0 }; query = query.eq("category_id", c.id); }
    if (q) query = query.ilike("name", `%${q.replace(/[%_\\]/g, "\\$&")}%`);   // curingas escapados
    if (ofertas) query = query.not("sale_price_cents", "is", null);
    if (min) query = query.gte("price_cents", min * 100);
    if (max) query = query.lte("price_cents", max * 100);
    query = ordem === "menor" ? query.order("price_cents") : ordem === "maior" ? query.order("price_cents", { ascending: false }) : query.order("created_at", { ascending: false });
    const { data, count, error } = await query.range((page - 1) * PAGE, page * PAGE - 1);
    if (error) throw new Error("Não foi possível carregar os produtos.");
    let rows = (data ?? []) as unknown as ProductRow[];
    if (disp) rows = rows.filter((p) => (p.product_variants ?? []).some((v) => v.active && v.stock - v.reserved > 0));
    return { rows, total: count ?? 0 };
  }, [categoria, q, ofertas, ordem, min, max, disp, page]);

  const set = (k: string, v: string) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); n.delete("p"); setSp(n); };
  const pages = Math.max(1, Math.ceil((res.data?.total ?? 0) / PAGE));
  return (
    <div className="container section">
      <h1>Loja</h1>
      <form className="row-between" style={{ marginBottom: 24, alignItems: "flex-end" }} onSubmit={(e) => e.preventDefault()} aria-label="Filtros">
        <div className="field" style={{ margin: 0 }}><label htmlFor="cat">Categoria</label>
          <select id="cat" value={categoria} onChange={(e) => set("categoria", e.target.value)}><option value="">Todas</option>{cats.data?.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}</select></div>
        <div className="field" style={{ margin: 0 }}><label htmlFor="min">Preço mín. (R$)</label><input id="min" type="number" min={0} defaultValue={min || ""} onBlur={(e) => set("min", e.target.value)} /></div>
        <div className="field" style={{ margin: 0 }}><label htmlFor="max">Preço máx. (R$)</label><input id="max" type="number" min={0} defaultValue={max || ""} onBlur={(e) => set("max", e.target.value)} /></div>
        <div className="field" style={{ margin: 0 }}><label htmlFor="ord">Ordenar</label>
          <select id="ord" value={ordem} onChange={(e) => set("ordem", e.target.value)}><option value="novidades">Novidades</option><option value="menor">Menor preço</option><option value="maior">Maior preço</option></select></div>
        <label><input type="checkbox" checked={disp} onChange={(e) => set("disp", e.target.checked ? "1" : "")} /> Somente disponíveis</label>
      </form>
      {res.loading ? <Spinner /> : res.error ? <div className="notice error" role="alert">{res.error}</div> :
        res.data!.rows.length === 0 ? <div className="empty"><h3>Nenhum produto encontrado</h3><p>Ajuste os filtros ou volte mais tarde.</p></div> :
        <div className="grid">{res.data!.rows.map((p) => <ProductCard key={p.id} p={p} />)}</div>}
      {pages > 1 && <nav className="row-between" style={{ marginTop: 32, justifyContent: "center" }} aria-label="Paginação">
        <button className="btn ghost sm" disabled={page <= 1} onClick={() => set("p", String(page - 1))}>Anterior</button>
        <span>Página {page} de {pages}</span>
        <button className="btn ghost sm" disabled={page >= pages} onClick={() => set("p", String(page + 1))}>Próxima</button></nav>}
    </div>
  );
}
