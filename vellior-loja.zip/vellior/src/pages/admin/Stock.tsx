import { useState } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { Spinner } from "../../components/Guards";

type V = { id: string; sku: string; label: string; stock: number; reserved: number; low_stock_threshold: number; products: { name: string } };
export default function Stock() {
  const { data, loading, reload } = useAsync(async () => ((await supabase.from("product_variants").select("id,sku,label,stock,reserved,low_stock_threshold,products(name)").order("sku")).data ?? []) as unknown as V[]);
  type M = { id: number; delta: number; kind: string; reason: string | null; created_at: string; product_variants: { sku: string } | null };
  const moves = useAsync(async () => ((await supabase.from("stock_movements").select("id,delta,kind,reason,created_at,product_variants(sku)").order("id", { ascending: false }).limit(20)).data ?? []) as unknown as M[]);
  const [delta, setDelta] = useState<Record<string, string>>({}); const [reason, setReason] = useState<Record<string, string>>({}); const [msg, setMsg] = useState("");
  async function adjust(v: V) {
    const d = Number(delta[v.id]);
    if (!Number.isInteger(d) || d === 0) { setMsg("Informe uma quantidade inteira diferente de zero."); return; }
    const { error } = await supabase.rpc("admin_adjust_stock", { p_variant: v.id, p_delta: d, p_reason: reason[v.id] ?? "" });
    setMsg(error ? (error.message.includes("reason_required") ? "Informe o motivo." : error.message.includes("stock_below_reserved") ? "Estoque não pode ficar abaixo do reservado." : "Sem permissão.") : "Estoque ajustado.");
    setDelta({ ...delta, [v.id]: "" }); await reload(); await moves.reload();
  }
  return <><h1>Estoque</h1>{msg && <div className="notice" role="status">{msg}</div>}
    {loading ? <Spinner /> : <div className="card tablewrap"><table><thead><tr><th>SKU</th><th>Produto</th><th>Físico</th><th>Reservado</th><th>Disponível</th><th>Ajuste</th></tr></thead>
      <tbody>{data!.map((v) => { const av = v.stock - v.reserved; return <tr key={v.id}><td>{v.sku}</td><td>{v.products.name} <span className="muted small">{v.label}</span></td><td>{v.stock}</td><td>{v.reserved}</td><td>{av} {av <= v.low_stock_threshold && <span className="pill bad">baixo</span>}</td>
        <td style={{ display: "flex", gap: 6 }}><input aria-label={`Ajuste de ${v.sku}`} style={{ width: 70 }} inputMode="numeric" placeholder="±" value={delta[v.id] ?? ""} onChange={(e) => setDelta({ ...delta, [v.id]: e.target.value })} /><input aria-label={`Motivo ${v.sku}`} placeholder="Motivo" maxLength={200} value={reason[v.id] ?? ""} onChange={(e) => setReason({ ...reason, [v.id]: e.target.value })} /><button className="btn sm" onClick={() => adjust(v)}>Aplicar</button></td></tr>; })}</tbody></table></div>}
    <h3 style={{ marginTop: 24 }}>Últimas movimentações</h3><div className="card tablewrap"><table><thead><tr><th>Quando</th><th>SKU</th><th>Tipo</th><th>Δ</th><th>Motivo</th></tr></thead>
      <tbody>{(moves.data ?? []).map((m) => <tr key={m.id}><td>{new Date(m.created_at).toLocaleString("pt-BR")}</td><td>{m.product_variants?.sku}</td><td>{m.kind}</td><td>{m.delta}</td><td>{m.reason}</td></tr>)}</tbody></table></div></>;
}
