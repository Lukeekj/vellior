import { useState } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { formatBRL } from "../../lib/money";
import { Spinner } from "../../components/Guards";

type D = { paid_orders: number; gross_cents: number; discount_cents: number; refunded_cents: number; net_estimated_cents: number; awaiting_payment: number; low_stock: number; top_products: { product_name: string; qty: number }[]; daily: { day: string; total_cents: number }[] };
export default function Dashboard() {
  const [days, setDays] = useState(30);
  const { data, loading, error } = useAsync(async () => {
    const to = new Date(Date.now() + 86400000), from = new Date(Date.now() - days * 86400000);
    const { data, error } = await supabase.rpc("admin_dashboard", { p_from: from.toISOString(), p_to: to.toISOString() });
    if (error) throw new Error("Sem permissão ou erro ao carregar.");
    return data as D;
  }, [days]);
  const max = Math.max(1, ...(data?.daily ?? []).map((d) => d.total_cents));
  return <><div className="row-between"><h1>Dashboard</h1>
    <div className="field" style={{ margin: 0 }}><label htmlFor="per">Período</label><select id="per" value={days} onChange={(e) => setDays(Number(e.target.value))}><option value={7}>7 dias</option><option value={30}>30 dias</option><option value={90}>90 dias</option></select></div></div>
    {loading ? <Spinner /> : error ? <div className="notice error">{error}</div> : <>
      <div className="stats">
        <div className="card stat"><div className="small muted">Pedidos pagos</div><div className="v">{data!.paid_orders}</div></div>
        <div className="card stat"><div className="small muted">Receita bruta (produtos + frete)</div><div className="v">{formatBRL(data!.gross_cents)}</div></div>
        <div className="card stat"><div className="small muted">Descontos</div><div className="v">{formatBRL(data!.discount_cents)}</div></div>
        <div className="card stat"><div className="small muted">Reembolsos</div><div className="v">{formatBRL(data!.refunded_cents)}</div></div>
        <div className="card stat"><div className="small muted">Líquido estimado*</div><div className="v">{formatBRL(data!.net_estimated_cents)}</div></div>
        <div className="card stat"><div className="small muted">Ticket médio</div><div className="v">{data!.paid_orders ? formatBRL(Math.round(data!.net_estimated_cents / data!.paid_orders)) : "—"}</div></div>
        <div className="card stat"><div className="small muted">Aguardando pagamento</div><div className="v">{data!.awaiting_payment}</div></div>
        <div className="card stat"><div className="small muted">Estoque baixo</div><div className="v">{data!.low_stock}</div></div></div>
      <p className="small muted">*Faturamento não é lucro: o valor líquido desconta apenas descontos e reembolsos, sem custos de produtos, taxas ou impostos.</p>
      <div className="two" style={{ alignItems: "start" }}>
        <section className="card"><h3>Evolução de vendas</h3>{data!.daily.length === 0 ? <p className="muted">Sem vendas pagas no período.</p> : <div className="bars" role="img" aria-label="Vendas por dia">{data!.daily.map((d) => <div key={d.day} title={`${d.day}: ${formatBRL(d.total_cents)}`} style={{ height: `${(d.total_cents / max) * 100}%` }} />)}</div>}</section>
        <section className="card"><h3>Mais vendidos</h3>{data!.top_products.length === 0 ? <p className="muted">Sem dados de vendas reais.</p> : <ol>{data!.top_products.map((t) => <li key={t.product_name}>{t.product_name} — {t.qty}</li>)}</ol>}</section></div></>}</>;
}
