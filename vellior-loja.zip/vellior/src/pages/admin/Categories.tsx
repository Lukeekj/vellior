import { useState, type FormEvent } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { slugify } from "../../lib/validation";
import { Spinner } from "../../components/Guards";

export default function Categories() {
  const { data, loading, reload } = useAsync(async () => (await supabase.from("categories").select("*").order("position")).data ?? []);
  const [name, setName] = useState(""); const [desc, setDesc] = useState(""); const [msg, setMsg] = useState("");
  async function create(e: FormEvent) {
    e.preventDefault(); const slug = slugify(name);
    if (name.trim().length < 2 || !slug) { setMsg("Informe um nome válido."); return; }
    const { error } = await supabase.from("categories").insert({ name: name.trim(), slug, description: desc || null, position: (data?.length ?? 0) + 1 });
    setMsg(error ? "Não foi possível criar (slug duplicado?)." : ""); if (!error) { setName(""); setDesc(""); await reload(); }
  }
  async function toggle(id: string, published: boolean) { await supabase.from("categories").update({ published: !published }).eq("id", id); await reload(); }
  return <><h1>Categorias</h1>
    <form className="card" onSubmit={create} noValidate style={{ marginBottom: 24 }}>
      <div className="field"><label htmlFor="cn">Nome</label><input id="cn" value={name} onChange={(e) => setName(e.target.value)} /></div>
      <div className="field"><label htmlFor="cd">Descrição</label><input id="cd" value={desc} onChange={(e) => setDesc(e.target.value)} /></div>
      {msg && <div className="notice error" role="alert">{msg}</div>}<button className="btn sm">Criar categoria</button></form>
    {loading ? <Spinner /> : <div className="card tablewrap"><table><thead><tr><th>Nome</th><th>Slug</th><th>Publicada</th></tr></thead>
      <tbody>{(data ?? []).map((c: { id: string; name: string; slug: string; published: boolean }) => <tr key={c.id}><td>{c.name}</td><td>{c.slug}</td><td><button className="btn ghost sm" onClick={() => toggle(c.id, c.published)}>{c.published ? "Despublicar" : "Publicar"}</button></td></tr>)}</tbody></table></div>}</>;
}
