import { useState } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { parseBRLToCents, formatBRL } from "../../lib/money";
import { Spinner } from "../../components/Guards";

export default function Settings() {
  const { data, loading, reload } = useAsync(async () => (await supabase.from("store_settings").select("key,value").eq("key", "shipping").maybeSingle()).data);
  const [flat, setFlat] = useState(""); const [free, setFree] = useState(""); const [msg, setMsg] = useState("");
  async function save() {
    const f = parseBRLToCents(flat || "0"), fr = free ? parseBRLToCents(free) : null;
    if (f == null || (free && fr == null)) { setMsg("Valores inválidos."); return; }
    const { error } = await supabase.from("store_settings").upsert({ key: "shipping", value: { flat_cents: f, free_over_cents: fr }, is_public: false, updated_at: new Date().toISOString() });
    setMsg(error ? "Sem permissão." : "Regra de frete salva."); await reload();
  }
  const cur = data?.value as { flat_cents?: number; free_over_cents?: number | null } | undefined;
  return <><h1>Configurações</h1>
    <section className="card" style={{ maxWidth: 520 }}><h3>Frete (regra simples)</h3>
      <p className="small muted">Enquanto não houver integração com transportadora (não implementada), o frete usa uma regra fixa definida aqui. Sem regra salva, o frete é R$ 0,00.</p>
      {loading ? <Spinner /> : <p className="small">Atual: {cur ? `${formatBRL(cur.flat_cents ?? 0)}${cur.free_over_cents ? `, grátis acima de ${formatBRL(cur.free_over_cents)}` : ""}` : "nenhuma"}</p>}
      <div className="field"><label htmlFor="fl">Frete fixo (R$)</label><input id="fl" value={flat} onChange={(e) => setFlat(e.target.value)} /></div>
      <div className="field"><label htmlFor="fr">Frete grátis acima de (R$, opcional)</label><input id="fr" value={free} onChange={(e) => setFree(e.target.value)} /></div>
      {msg && <div className="notice" role="status">{msg}</div>}<button className="btn sm" onClick={save}>Salvar</button></section></>;
}
