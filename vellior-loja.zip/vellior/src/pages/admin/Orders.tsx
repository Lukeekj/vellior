import { useState } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { useAuth } from "../../context/AuthContext";
import { formatBRL } from "../../lib/money";
import { Spinner } from "../../components/Guards";
import { FUL_LABEL, PAY_LABEL, pillClass } from "../Account";

type O = { id: string; number: number; created_at: string; total_cents: number; refunded_cents: number; payment_status: string; fulfillment_status: string; tracking_code: string | null; admin_notes: string | null; shipping_address: { recipient: string; city: string; state: string }; order_items: { id: string; product_name: string; variant_label: string; quantity: number }[] };

export default function Orders() {
  const { isAdmin } = useAuth();
  const [filter, setFilter] = useState(""); const [search, setSearch] = useState(""); const [msg, setMsg] = useState("");
  const [edit, setEdit] = useState<Record<string, { status: string; tracking: string; notes: string }>>({});
  const { data, loading, reload } = useAsync(async () => {
    let q = supabase.from("orders").select("id,number,created_at,total_cents,refunded_cents,payment_status,fulfillment_status,tracking_code,admin_notes,shipping_address,order_items(id,product_name,variant_label,quantity)").order("created_at", { ascending: false }).limit(100);
    if (filter) q = q.eq("payment_status", filter);
    if (/^\d{1,10}$/.test(search.trim())) q = q.eq("number", Number(search.trim()));
    return ((await q).data ?? []) as O[];
  }, [filter, search]);

  async function save(o: O) {
    const e = edit[o.id] ?? { status: o.fulfillment_status, tracking: o.tracking_code ?? "", notes: o.admin_notes ?? "" };
    const { error } = await supabase.rpc("admin_update_fulfillment", { p_order: o.id, p_status: e.status, p_tracking: e.tracking || null, p_notes: e.notes || null });
    setMsg(error ? (error.message.includes("order_not_paid") ? "Só é possível enviar pedidos pagos." : "Sem permissão ou dados inválidos.") : "Pedido atualizado.");
    await reload();
  }
  async function refund(o: O) {
    if (!confirm(`Reembolsar o valor restante do pedido #${o.number} pelo Mercado Pago? Esta ação não pode ser desfeita.`)) return;
    const { data: r, error } = await supabase.functions.invoke("admin-payments", { body: { action: "refund", order_id: o.id } });
    setMsg(error || r?.error ? "Reembolso não realizado (verifique credenciais e permissões)." : "Reembolso solicitado."); await reload();
  }
  return <><h1>Pedidos</h1>
    <div className="row-between" style={{ marginBottom: 16 }}>
      <div className="field" style={{ margin: 0 }}><label htmlFor="st">Pagamento</label><select id="st" value={filter} onChange={(e) => setFilter(e.target.value)}><option value="">Todos</option>{Object.entries(PAY_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
      <div className="field" style={{ margin: 0 }}><label htmlFor="sn">Nº do pedido</label><input id="sn" inputMode="numeric" value={search} onChange={(e) => setSearch(e.target.value)} /></div></div>
    {msg && <div className="notice" role="status">{msg}</div>}
    {loading ? <Spinner /> : (data?.length ?? 0) === 0 ? <div className="card empty">Nenhum pedido.</div> :
      data!.map((o) => { const e = edit[o.id] ?? { status: o.fulfillment_status, tracking: o.tracking_code ?? "", notes: o.admin_notes ?? "" };
        return <div className="card" key={o.id} style={{ marginBottom: 12 }}>
          <div className="row-between"><strong>#{o.number}</strong><span className="small muted">{new Date(o.created_at).toLocaleString("pt-BR")}</span><span>{formatBRL(o.total_cents)}</span><span className={pillClass(o.payment_status)}>{PAY_LABEL[o.payment_status]}</span></div>
          <p className="small">{o.shipping_address.recipient} — {o.shipping_address.city}/{o.shipping_address.state} · {o.order_items.map((i) => `${i.quantity}× ${i.product_name} (${i.variant_label})`).join("; ")}</p>
          <div className="row-between" style={{ alignItems: "flex-end" }}>
            <div className="field" style={{ margin: 0 }}><label htmlFor={`f${o.id}`}>Logística</label><select id={`f${o.id}`} value={e.status} onChange={(ev) => setEdit({ ...edit, [o.id]: { ...e, status: ev.target.value } })}>{Object.entries(FUL_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select></div>
            <div className="field" style={{ margin: 0 }}><label htmlFor={`t${o.id}`}>Rastreio</label><input id={`t${o.id}`} maxLength={60} value={e.tracking} onChange={(ev) => setEdit({ ...edit, [o.id]: { ...e, tracking: ev.target.value } })} /></div>
            <div className="field" style={{ margin: 0, flex: 1 }}><label htmlFor={`n${o.id}`}>Observações internas</label><input id={`n${o.id}`} maxLength={2000} value={e.notes} onChange={(ev) => setEdit({ ...edit, [o.id]: { ...e, notes: ev.target.value } })} /></div>
            <button className="btn sm" onClick={() => save(o)}>Salvar</button>
            {isAdmin && ["paid", "partially_refunded"].includes(o.payment_status) && <button className="btn danger sm" onClick={() => refund(o)}>Reembolsar</button>}</div></div>; })}</>;
}
