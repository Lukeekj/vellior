import { useState } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { Spinner } from "../../components/Guards";

type St = { access_token_configured: boolean; access_token_masked: string | null; webhook_secret_configured: boolean; environment: string; instructions: string };
export default function Payments() {
  const methods = useAsync(async () => (await supabase.from("payment_methods_config").select("*").order("method")).data ?? []);
  const status = useAsync(async () => { const { data, error } = await supabase.functions.invoke("admin-payments", { body: { action: "status" } }); if (error) throw new Error("Função admin-payments indisponível (não implantada?)."); return data as St; });
  const [msg, setMsg] = useState("");
  async function toggle(method: string, enabled: boolean) {
    if (!enabled && status.data && !status.data.access_token_configured) { setMsg("Configure as credenciais antes de habilitar um método."); return; }
    if (!enabled && status.data?.environment === "production" && !confirm("Habilitar pagamento REAL em produção?")) return;
    const { error } = await supabase.from("payment_methods_config").update({ enabled: !enabled }).eq("method", method);
    setMsg(error ? "Sem permissão." : ""); await methods.reload();
  }
  async function test() { const { data, error } = await supabase.functions.invoke("admin-payments", { body: { action: "test" } }); setMsg(error || !data?.ok ? "Falha de conectividade com o provedor." : "Conectividade OK."); }
  return <><h1>Configurações › Pagamentos</h1>{msg && <div className="notice" role="status">{msg}</div>}
    <section className="card" style={{ marginBottom: 16 }}><h3>Mercado Pago</h3>
      {status.loading ? <Spinner /> : status.error ? <div className="notice error">{status.error}</div> : <>
        <ul><li>Access token: {status.data!.access_token_configured ? `configurado (${status.data!.access_token_masked})` : "não configurado"}</li>
          <li>Segredo do webhook: {status.data!.webhook_secret_configured ? "configurado" : "não configurado"}</li><li>Ambiente: <strong>{status.data!.environment}</strong> (alterado apenas via secret MP_ENV no backend)</li></ul>
        <p className="small muted">{status.data!.instructions}</p><button className="btn ghost sm" onClick={test}>Testar conectividade</button></>}</section>
    <section className="card"><h3>Métodos</h3>{methods.loading ? <Spinner /> : (methods.data ?? []).map((m: { method: string; enabled: boolean }) =>
      <div key={m.method} className="row-between" style={{ marginBottom: 8 }}><span>{m.method === "pix" ? "Pix" : "Cartão de crédito (interface ainda não implementada)"}</span><button className="btn ghost sm" onClick={() => toggle(m.method, m.enabled)}>{m.enabled ? "Desabilitar" : "Habilitar"}</button></div>)}</section></>;
}
