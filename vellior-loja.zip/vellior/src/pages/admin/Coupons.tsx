import { useState, type FormEvent } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { formatBRL, parseBRLToCents } from "../../lib/money";
import { Spinner } from "../../components/Guards";

export default function Coupons() {
  const { data, loading, reload } = useAsync(async () => (await supabase.from("coupons").select("*").order("created_at", { ascending: false })).data ?? []);
  const [f, setF] = useState({ code: "", kind: "percent", value: "", min: "", exp: "", max: "" }); const [msg, setMsg] = useState("");
  async function create(e: FormEvent) {
    e.preventDefault();
    const code = f.code.trim().toUpperCase();
    const value = f.kind === "percent" ? Number(f.value) : parseBRLToCents(f.value);
    const min = f.min ? parseBRLToCents(f.min) : 0;
    if (!/^[A-Z0-9_-]{3,40}$/.test(code) || !value || value <= 0 || (f.kind === "percent" && (value > 100 || !Number.isInteger(value))) || min == null) { setMsg("Confira código, valor (percentual 1–100) e mínimo."); return; }
    const { error } = await supabase.from("coupons").insert({ code, kind: f.kind, value, min_subtotal_cents: min, expires_at: f.exp ? new Date(f.exp).toISOString() : null, max_uses: f.max ? Number(f.max) : null });
    setMsg(error ? "Não foi possível criar (código duplicado ou inválido)." : "Cupom criado."); if (!error) { setF({ code: "", kind: "percent", value: "", min: "", exp: "", max: "" }); await reload(); }
  }
  async function toggle(id: string, active: boolean) { await supabase.from("coupons").update({ active: !active }).eq("id", id); await reload(); }
  return <><h1>Cupons</h1>
    <form className="card" onSubmit={create} noValidate style={{ marginBottom: 24 }}>
      <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))" }}>
        <div className="field"><label htmlFor="cc">Código</label><input id="cc" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} /></div>
        <div className="field"><label htmlFor="ck">Tipo</label><select id="ck" value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}><option value="percent">Percentual</option><option value="fixed">Valor fixo</option></select></div>
        <div className="field"><label htmlFor="cv">{f.kind === "percent" ? "Percentual (%)" : "Valor (R$)"}</label><input id="cv" value={f.value} onChange={(e) => setF({ ...f, value: e.target.value })} /></div>
        <div className="field"><label htmlFor="cm">Compra mínima (R$)</label><input id="cm" value={f.min} onChange={(e) => setF({ ...f, min: e.target.value })} /></div>
        <div className="field"><label htmlFor="ce">Validade</label><input id="ce" type="date" value={f.exp} onChange={(e) => setF({ ...f, exp: e.target.value })} /></div>
        <div className="field"><label htmlFor="cx">Limite de usos</label><input id="cx" inputMode="numeric" value={f.max} onChange={(e) => setF({ ...f, max: e.target.value })} /></div></div>
      {msg && <div className="notice" role="status">{msg}</div>}<button className="btn sm">Criar cupom</button></form>
    {loading ? <Spinner /> : <div className="card tablewrap"><table><thead><tr><th>Código</th><th>Desconto</th><th>Mínimo</th><th>Usos</th><th>Validade</th><th>Ativo</th></tr></thead>
      <tbody>{(data ?? []).map((c: { id: string; code: string; kind: string; value: number; min_subtotal_cents: number; uses: number; max_uses: number | null; expires_at: string | null; active: boolean }) => <tr key={c.id}><td>{c.code}</td><td>{c.kind === "percent" ? `${c.value}%` : formatBRL(c.value)}</td><td>{formatBRL(c.min_subtotal_cents)}</td><td>{c.uses}{c.max_uses ? `/${c.max_uses}` : ""}</td><td>{c.expires_at ? new Date(c.expires_at).toLocaleDateString("pt-BR") : "—"}</td><td><button className="btn ghost sm" onClick={() => toggle(c.id, c.active)}>{c.active ? "Desativar" : "Ativar"}</button></td></tr>)}</tbody></table></div>}</>;
}
