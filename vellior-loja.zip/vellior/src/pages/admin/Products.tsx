import { useState, type FormEvent } from "react";
import { supabase } from "../../lib/supabase";
import { useAsync } from "../../hooks/useAsync";
import { formatBRL, parseBRLToCents } from "../../lib/money";
import { slugify } from "../../lib/validation";
import { Spinner } from "../../components/Guards";

const MAX = 5 * 1024 * 1024, TYPES = ["image/jpeg", "image/png", "image/webp"];
type P = { id: string; slug: string; name: string; price_cents: number; sale_price_cents: number | null; published: boolean; archived: boolean; featured: boolean; is_demo: boolean; product_variants: { id: string; sku: string; label: string; stock: number; reserved: number }[]; product_images: { id: string; path: string }[] };

export default function Products() {
  const list = useAsync(async () => (await supabase.from("products").select("id,slug,name,price_cents,sale_price_cents,published,archived,featured,is_demo,product_variants(id,sku,label,stock,reserved),product_images(id,path)").order("created_at", { ascending: false })).data as P[] ?? []);
  const cats = useAsync(async () => (await supabase.from("categories").select("id,name")).data ?? []);
  const [f, setF] = useState({ name: "", price: "", sale: "", cost: "", category: "", sku: "", label: "Único", stock: "0", description: "", demo: true });
  const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);

  async function create(e: FormEvent) {
    e.preventDefault(); setMsg("");
    const price = parseBRLToCents(f.price), sale = f.sale ? parseBRLToCents(f.sale) : null, cost = f.cost ? parseBRLToCents(f.cost) : null;
    if (f.name.trim().length < 2 || price == null || (f.sale && sale == null) || (sale != null && sale >= price)) { setMsg("Confira nome e preços (promoção deve ser menor que o preço)."); return; }
    if (!f.sku.trim() || !/^\d+$/.test(f.stock)) { setMsg("Informe SKU e estoque válidos."); return; }
    setBusy(true);
    const { data: p, error } = await supabase.from("products").insert({ slug: slugify(f.name) + "-" + Math.random().toString(36).slice(2, 6), name: f.name.trim(), description: f.description || null, price_cents: price, sale_price_cents: sale, category_id: f.category || null, is_demo: f.demo }).select("id").single();
    if (error || !p) { setBusy(false); setMsg("Não foi possível criar o produto."); return; }
    await supabase.from("product_variants").insert({ product_id: p.id, sku: f.sku.trim().toUpperCase(), label: f.label.trim() || "Único", stock: Number(f.stock) });
    if (cost != null) await supabase.from("product_costs").insert({ product_id: p.id, cost_cents: cost });
    setBusy(false); setF({ ...f, name: "", price: "", sale: "", cost: "", sku: "", description: "" }); setMsg("Produto criado como rascunho."); await list.reload();
  }
  async function upd(id: string, patch: Record<string, unknown>) { const { error } = await supabase.from("products").update(patch).eq("id", id); setMsg(error ? "Falha ao atualizar." : ""); await list.reload(); }
  async function upload(id: string, file: File | undefined) {
    if (!file) return;
    if (!TYPES.includes(file.type) || file.size > MAX) { setMsg("Imagem inválida: use JPG, PNG ou WebP até 5 MB."); return; }
    const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
    const path = `${id}/${crypto.randomUUID()}.${ext}`;
    const { error } = await supabase.storage.from("product-images").upload(path, file, { contentType: file.type });
    if (error) { setMsg("Falha no upload."); return; }
    await supabase.from("product_images").insert({ product_id: id, path, alt: null, position: 99 }); await list.reload();
  }
  return <><h1>Produtos</h1>
    <form className="card" onSubmit={create} noValidate style={{ marginBottom: 24 }}><h3>Novo produto</h3>
      <div className="grid" style={{ gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))" }}>
        {([["name", "Nome"], ["price", "Preço (R$)"], ["sale", "Preço promocional (R$)"], ["cost", "Custo (R$, restrito)"], ["sku", "SKU"], ["label", "Variante"], ["stock", "Estoque"]] as const).map(([k, l]) => <div className="field" key={k}><label htmlFor={`pf-${k}`}>{l}</label><input id={`pf-${k}`} value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} /></div>)}
        <div className="field"><label htmlFor="pf-cat">Categoria</label><select id="pf-cat" value={f.category} onChange={(e) => setF({ ...f, category: e.target.value })}><option value="">—</option>{cats.data?.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div></div>
      <div className="field"><label htmlFor="pf-d">Descrição</label><textarea id="pf-d" rows={3} value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} /></div>
      <label><input type="checkbox" checked={f.demo} onChange={(e) => setF({ ...f, demo: e.target.checked })} /> Produto de demonstração (exibe selo até ser substituído)</label>
      {msg && <div className="notice" role="status">{msg}</div>}<div style={{ marginTop: 12 }}><button className="btn sm" disabled={busy}>Criar produto</button></div></form>
    {list.loading ? <Spinner /> : <div className="card tablewrap"><table><thead><tr><th>Produto</th><th>Preço</th><th>Estoque</th><th>Status</th><th>Ações</th></tr></thead>
      <tbody>{(list.data ?? []).map((p) => <tr key={p.id}><td>{p.name} {p.is_demo && <span className="tag demo">Demo</span>}<div className="small muted">{p.product_variants.map((v) => v.sku).join(", ")} · {p.product_images.length} foto(s)</div></td>
        <td>{p.sale_price_cents != null ? <><span className="old">{formatBRL(p.price_cents)}</span>{formatBRL(p.sale_price_cents)}</> : formatBRL(p.price_cents)}</td>
        <td>{p.product_variants.reduce((s, v) => s + v.stock - v.reserved, 0)}</td>
        <td>{p.archived ? "Arquivado" : p.published ? "Publicado" : "Rascunho"}{p.featured && " · Destaque"}</td>
        <td style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          <button className="btn ghost sm" onClick={() => upd(p.id, { published: !p.published })}>{p.published ? "Despublicar" : "Publicar"}</button>
          <button className="btn ghost sm" onClick={() => upd(p.id, { featured: !p.featured })}>Destaque</button>
          <button className="btn ghost sm" onClick={() => { if (confirm(`Arquivar "${p.name}"?`)) void upd(p.id, { archived: true, published: false }); }}>Arquivar</button>
          <label className="btn ghost sm" style={{ cursor: "pointer" }}>Foto<input type="file" accept={TYPES.join(",")} className="sr-only" onChange={(e) => upload(p.id, e.target.files?.[0])} /></label></td></tr>)}</tbody></table></div>}</>;
}
