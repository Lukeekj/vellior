import { Link, NavLink, Outlet } from "react-router-dom";
import { useAuth } from "../../context/AuthContext";
import { useSeo } from "../../hooks/useSeo";

const LINKS = [["/admin", "Dashboard", true], ["/admin/produtos", "Produtos"], ["/admin/categorias", "Categorias"], ["/admin/pedidos", "Pedidos"], ["/admin/estoque", "Estoque"], ["/admin/cupons", "Cupons"], ["/admin/pagamentos", "Pagamentos"], ["/admin/configuracoes", "Configurações"]] as const;
export default function AdminLayout() {
  useSeo("Painel — VELLIOR");
  const { isAdmin } = useAuth();
  return <div className="admin"><aside><div className="logo" style={{ fontSize: "1.3rem", marginBottom: 16, display: "block" }}>VELLIOR</div>
    {LINKS.map(([to, label, end]) => (!isAdmin && to !== "/admin" && to !== "/admin/pedidos") ? null : <NavLink key={to} to={to} end={!!end}>{label}</NavLink>)}
    <Link to="/" style={{ marginTop: 16 }}>← Ver loja</Link></aside><main><Outlet /></main></div>;
}
