import { Link } from "react-router-dom";
import { useSeo } from "../hooks/useSeo";

const Draft = () => <div className="notice">Texto provisório. Este documento deve ser redigido e revisado por assessoria jurídica antes da publicação da loja. Não foi gerado conteúdo legal definitivo.</div>;
export const Terms = () => { useSeo("Termos de uso — VELLIOR"); return <div className="container section"><h1>Termos de uso</h1><Draft /></div>; };
export const Privacy = () => { useSeo("Política de privacidade — VELLIOR"); return <div className="container section"><h1>Política de privacidade</h1><Draft />
  <p>Dados coletados: nome, e-mail, telefone (opcional), endereços de entrega e histórico de pedidos — apenas para cadastro, entrega, pagamento e atendimento. Dados de cartão nunca são armazenados pela loja.</p></div>; };
export const Cookies = () => { useSeo("Política de cookies — VELLIOR"); return <div className="container section"><h1>Política de cookies</h1><Draft />
  <p>A loja usa armazenamento local do navegador para manter sua sessão e seu carrinho. Não há rastreamento publicitário configurado.</p></div>; };
export const NotFound = () => { useSeo("Página não encontrada — VELLIOR"); return <div className="container empty"><h1>Página não encontrada</h1><p>O endereço acessado não existe.</p><Link className="btn" to="/">Voltar ao início</Link></div>; };
