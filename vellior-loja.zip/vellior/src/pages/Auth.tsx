import { useEffect, useRef, useState, type FormEvent } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { supabase, socialProviders, supabaseConfigured } from "../lib/supabase";
import { loginSchema, signupSchema } from "../lib/validation";
import { safeNext } from "../lib/safeRedirect";
import { useAuth } from "../context/AuthContext";
import { useSeo } from "../hooks/useSeo";

const Field = ({ id, label, type = "text", value, onChange, error, autoComplete }: { id: string; label: string; type?: string; value: string; onChange: (v: string) => void; error?: string; autoComplete?: string }) => (
  <div className="field"><label htmlFor={id}>{label}</label>
    <input id={id} type={type} value={value} autoComplete={autoComplete} aria-invalid={!!error} aria-describedby={error ? `${id}-e` : undefined} onChange={(e) => onChange(e.target.value)} />
    {error && <span id={`${id}-e`} className="err" role="alert">{error}</span>}</div>
);

function Social({ next }: { next: string }) {
  const [msg, setMsg] = useState("");
  const go = async (provider: "google" | "apple") => {
    if (!socialProviders[provider]) { setMsg(`Login com ${provider === "google" ? "Google" : "Apple"} ainda não foi configurado.`); return; }
    const { error } = await supabase.auth.signInWithOAuth({ provider, options: { redirectTo: `${location.origin}/auth/callback?next=${encodeURIComponent(next)}` } });
    if (error) setMsg("Não foi possível iniciar o login social.");
  };
  return <div style={{ display: "grid", gap: 8, margin: "16px 0" }}>
    <button type="button" className="btn ghost" onClick={() => go("google")} aria-disabled={!socialProviders.google}>Continuar com Google</button>
    <button type="button" className="btn ghost" onClick={() => go("apple")} aria-disabled={!socialProviders.apple}>Continuar com Apple</button>
    {msg && <div className="notice" role="status">{msg}</div>}</div>;
}

export function Login() {
  useSeo("Entrar — VELLIOR");
  const [sp] = useSearchParams(); const next = safeNext(sp.get("next"));
  const nav = useNavigate(); const { user } = useAuth();
  const [email, setEmail] = useState(""); const [password, setPassword] = useState("");
  const [errs, setErrs] = useState<Record<string, string>>({}); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  const fails = useRef(0); const lockUntil = useRef(0);
  useEffect(() => { if (user) nav(next, { replace: true }); }, [user, next, nav]);

  async function submit(e: FormEvent) {
    e.preventDefault(); setMsg("");
    if (Date.now() < lockUntil.current) { setMsg("Muitas tentativas. Aguarde alguns segundos."); return; }
    const r = loginSchema.safeParse({ email, password });
    if (!r.success) { setErrs(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message]))); return; }
    setErrs({}); setBusy(true);
    const { error } = await supabase.auth.signInWithPassword(r.data);
    setBusy(false);
    if (error) { fails.current++; if (fails.current >= 5) lockUntil.current = Date.now() + 30000;
      setMsg("E-mail ou senha incorretos, ou e-mail ainda não confirmado."); }   // mensagem genérica
  }
  return <div className="container section" style={{ maxWidth: 440 }}>
    <h1>Entrar</h1>
    {!supabaseConfigured && <div className="notice error">Backend não configurado.</div>}
    <form onSubmit={submit} noValidate>
      <Field id="email" label="E-mail" type="email" autoComplete="email" value={email} onChange={setEmail} error={errs.email} />
      <Field id="password" label="Senha" type="password" autoComplete="current-password" value={password} onChange={setPassword} error={errs.password} />
      {msg && <div className="notice error" role="alert">{msg}</div>}
      <button className="btn" style={{ width: "100%" }} disabled={busy}>{busy ? "Entrando…" : "Entrar"}</button>
    </form>
    <Social next={next} />
    <p className="small"><Link to="/esqueci-senha">Esqueci minha senha</Link> · <Link to={`/criar-conta?next=${encodeURIComponent(next)}`}>Criar conta</Link></p>
  </div>;
}

export function Signup() {
  useSeo("Criar conta — VELLIOR");
  const [sp] = useSearchParams(); const next = safeNext(sp.get("next"));
  const [f, setF] = useState({ fullName: "", email: "", password: "", confirm: "", acceptTerms: false });
  const [errs, setErrs] = useState<Record<string, string>>({}); const [done, setDone] = useState(false); const [msg, setMsg] = useState(""); const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault(); setMsg("");
    const r = signupSchema.safeParse(f);
    if (!r.success) { setErrs(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), i.message]))); return; }
    setErrs({}); setBusy(true);
    const { error } = await supabase.auth.signUp({ email: r.data.email, password: r.data.password,
      options: { data: { full_name: r.data.fullName, accepted_terms: "true" }, emailRedirectTo: `${location.origin}/auth/callback?next=${encodeURIComponent(next)}` } });
    setBusy(false);
    if (error && error.status === 429) { setMsg("Muitas tentativas. Tente novamente em instantes."); return; }
    setDone(true);   // resposta idêntica exista ou não a conta (anti-enumeração)
  }
  if (done) return <div className="container section" style={{ maxWidth: 480 }}><h1>Verifique seu e-mail</h1><p>Se os dados estiverem corretos, enviamos um link para confirmar seu cadastro. Depois de confirmar, você poderá <Link to={`/entrar?next=${encodeURIComponent(next)}`}>entrar</Link>.</p></div>;
  return <div className="container section" style={{ maxWidth: 480 }}>
    <h1>Criar conta</h1>
    <form onSubmit={submit} noValidate>
      <Field id="name" label="Nome completo" autoComplete="name" value={f.fullName} onChange={(v) => setF({ ...f, fullName: v })} error={errs.fullName} />
      <Field id="email" label="E-mail" type="email" autoComplete="email" value={f.email} onChange={(v) => setF({ ...f, email: v })} error={errs.email} />
      <Field id="password" label="Senha" type="password" autoComplete="new-password" value={f.password} onChange={(v) => setF({ ...f, password: v })} error={errs.password} />
      <Field id="confirm" label="Confirmar senha" type="password" autoComplete="new-password" value={f.confirm} onChange={(v) => setF({ ...f, confirm: v })} error={errs.confirm} />
      <div className="field"><label><input type="checkbox" checked={f.acceptTerms} onChange={(e) => setF({ ...f, acceptTerms: e.target.checked })} /> Li e aceito os <Link to="/termos" target="_blank">Termos de uso</Link> e a <Link to="/privacidade" target="_blank">Política de privacidade</Link>.</label>{errs.acceptTerms && <span className="err" role="alert">{errs.acceptTerms}</span>}</div>
      {msg && <div className="notice error" role="alert">{msg}</div>}
      <button className="btn" style={{ width: "100%" }} disabled={busy}>{busy ? "Criando…" : "Criar conta"}</button>
    </form>
    <Social next={next} />
    <p className="small">Já tem conta? <Link to="/entrar">Entrar</Link></p>
  </div>;
}

export function Forgot() {
  useSeo("Recuperar senha — VELLIOR");
  const [email, setEmail] = useState(""); const [done, setDone] = useState(false); const [busy, setBusy] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) return;
    setBusy(true);
    await supabase.auth.resetPasswordForEmail(email.trim().toLowerCase(), { redirectTo: `${location.origin}/redefinir-senha` });
    setBusy(false); setDone(true);   // sempre a mesma resposta
  }
  return <div className="container section" style={{ maxWidth: 440 }}><h1>Recuperar senha</h1>
    {done ? <p>Se existir uma conta com este e-mail, enviamos as instruções para redefinir a senha.</p> :
      <form onSubmit={submit} noValidate><Field id="email" label="E-mail" type="email" value={email} onChange={setEmail} /><button className="btn" disabled={busy}>Enviar link</button></form>}</div>;
}

export function Reset() {
  useSeo("Redefinir senha — VELLIOR");
  const [pw, setPw] = useState(""); const [msg, setMsg] = useState(""); const [ok, setOk] = useState(false);
  async function submit(e: FormEvent) {
    e.preventDefault();
    if (pw.length < 8 || !/[A-Za-z]/.test(pw) || !/\d/.test(pw)) { setMsg("Use ao menos 8 caracteres, com letras e números."); return; }
    const { error } = await supabase.auth.updateUser({ password: pw });
    if (error) setMsg("O link expirou ou é inválido. Solicite um novo."); else { setOk(true); await supabase.auth.signOut({ scope: "others" }); }
  }
  return <div className="container section" style={{ maxWidth: 440 }}><h1>Nova senha</h1>
    {ok ? <p>Senha atualizada. <Link to="/entrar">Entrar</Link></p> :
      <form onSubmit={submit} noValidate><Field id="pw" label="Nova senha" type="password" autoComplete="new-password" value={pw} onChange={setPw} />{msg && <div className="notice error" role="alert">{msg}</div>}<button className="btn">Salvar senha</button></form>}</div>;
}

export function AuthCallback() {
  const [sp] = useSearchParams(); const nav = useNavigate(); const { user, loading } = useAuth();
  useEffect(() => { if (!loading) nav(user ? safeNext(sp.get("next")) : "/entrar", { replace: true }); }, [loading, user, nav, sp]);
  return <div className="container section"><p>Confirmando…</p></div>;
}
