import { useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useAsync } from "../hooks/useAsync";
import { useAuth } from "../context/AuthContext";
import { formatBRL } from "../lib/money";
import { Spinner } from "../components/Guards";
import { useSeo } from "../hooks/useSeo";

export const PAY_LABEL: Record<string, string> = { awaiting_payment: "Aguardando pagamento", processing: "Pagamento em processamento", paid: "Pago", refused: "Pagamento recusado", expired: "Pagamento expirado", cancelled: "Cancelado", refunded: "Reembolsado", partially_refunded: "Parcialmente reembolsado" };
export const FUL_LABEL: Record<string, string> = { pending: "Pendente", preparing: "Em preparação", shipped: "Enviado", delivered: "Entregue", cancelled: "Cancelado" };
export const pillClass = (s: string) => (s === "paid" ? "pill paid" : ["refused", "expired", "cancelled"].includes(s) ? "pill bad" : "pill wait");

export function Account() {
  useSeo("Minha conta — VELLIOR");
  const { user, signOut } = useAuth();
  const prof = useAsync(async () => (await supabase.from("profiles").select("full_name,phone").eq("id", user!.id).single()).data, [user?.id]);
  const addrs = useAsync(async () => (await supabase.from("addresses").select("id,recipient,street,number,city,state,zip").order("created_at")).data ?? []);
  const [name, setName] = useState(""); const [phone, setPhone] = useState(""); const [msg, setMsg] = useState("");
  useEffect(() => { if (prof.data) { setName(prof.data.full_name); setPhone(prof.data.phone ?? ""); } }, [prof.data]);
  async function save() {
    if (name.trim().length < 2) { setMsg("Informe seu nome."); return; }
    const { error } = await supabase.from("profiles").update({ full_name: name.trim(), phone: phone.trim() || null }).eq("id", user!.id);
    setMsg(error ? "Não foi possível salvar." : "Dados atualizados.");
  }
  async function del(id: string) { if (confirm("Excluir este endereço?")) { await supabase.from("addresses").delete().eq("id", id); await addrs.reload(); } }
  return <div className="container section"><h1>Minha conta</h1>
    <div className="two" style={{ alignItems: "start" }}>
      <section className="card"><h2 style={{ fontSize: "1.4rem" }}>Dados pessoais</h2>
        <div className="field"><label htmlFor="n">Nome completo</label><input id="n" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} /></div>
        <div className="field"><label>E-mail</label><input value={user?.email ?? ""} disabled /></div>
        <div className="field"><label htmlFor="p">Telefone</label><input id="p" value={phone} maxLength={30} onChange={(e) => setPhone(e.target.value)} /></div>
        {msg && <div className="notice" role="status">{msg}</div>}
        <button className="btn sm" onClick={save}>Salvar</button> <button className="btn ghost sm" onClick={() => signOut()}>Sair</button>
        <p className="small muted" style={{ marginTop: 16 }}>Solicitações LGPD (acesso, correção e exclusão de dados): entre em contato com o atendimento da loja.</p></section>
      <section className="card"><h2 style={{ fontSize: "1.4rem" }}>Endereços</h2>
        {addrs.loading ? <Spinner /> : (addrs.data?.length ?? 0) === 0 ? <p className="muted">Nenhum endereço. Você pode cadastrar durante o checkout.</p> :
          addrs.data!.map((a) => <div key={a.id} className="row-between" style={{ marginBottom: 8 }}><span className="small">{a.recipient} — {a.street}, {a.number}, {a.city}/{a.state}, {a.zip}</span><button className="btn ghost sm" onClick={() => del(a.id)}>Excluir</button></div>)}
        <p><Link to="/conta/pedidos">Ver meus pedidos →</Link></p></section></div></div>;
}

export function Orders() {
  useSeo("Meus pedidos — VELLIOR");
  const { data, loading } = useAsync(async () => (await supabase.from("orders").select("id,number,created_at,total_cents,payment_status,fulfillment_status").order("created_at", { ascending: false })).data ?? []);
  if (loading) return <Spinner />;
  return <div className="container section"><h1>Meus pedidos</h1>
    {(data?.length ?? 0) === 0 ? <div className="empty">Você ainda não fez pedidos. <Link to="/loja">Ver produtos</Link></div> :
      <div className="tablewrap"><table><thead><tr><th>Pedido</th><th>Data</th><th>Total</th><th>Pagamento</th><th>Entrega</th></tr></thead>
        <tbody>{data!.map((o) => <tr key={o.id}><td><Link to={`/conta/pedidos/${o.id}`}>#{o.number}</Link></td><td>{new Date(o.created_at).toLocaleDateString("pt-BR")}</td><td>{formatBRL(o.total_cents)}</td><td><span className={pillClass(o.payment_status)}>{PAY_LABEL[o.payment_status]}</span></td><td>{FUL_LABEL[o.fulfillment_status]}</td></tr>)}</tbody></table></div>}</div>;
}

export function OrderDetail() {
  useSeo("Pedido — VELLIOR");
  const { id } = useParams(); const [sp] = useSearchParams();
  const { data, loading, reload } = useAsync(async () => {
    const { data: o } = await supabase.from("orders").select("*,order_items(*),payments(method,status,pix_qr_code,pix_expires_at)").eq("id", id ?? "").maybeSingle();
    return o;
  }, [id]);
  // Atualização periódica enquanto aguarda: o estado vem SEMPRE do banco (alterado pelo webhook), nunca do navegador.
  useEffect(() => { if (data && ["awaiting_payment", "processing"].includes(data.payment_status)) { const t = setInterval(reload, 6000); return () => clearInterval(t); } }, [data?.payment_status, reload]);
  const [copied, setCopied] = useState(false);
  if (loading && !data) return <Spinner />;
  if (!data) return <div className="container empty"><h1>Pedido não encontrado</h1></div>;
  const pix = (data.payments as { method: string; status: string; pix_qr_code: string | null }[] | null)?.find((p) => p.method === "pix" && p.pix_qr_code);
  const a = data.shipping_address as { recipient: string; street: string; number: string; district: string; city: string; state: string; zip: string };
  return <div className="container section"><h1>Pedido #{data.number}</h1>
    <p><span className={pillClass(data.payment_status)}>{PAY_LABEL[data.payment_status]}</span> · {FUL_LABEL[data.fulfillment_status]}{data.tracking_code && <> · Rastreio: <strong>{data.tracking_code}</strong></>}</p>
    {sp.get("pagamento") === "erro" && data.payment_status === "awaiting_payment" && <div className="notice error">Não foi possível gerar o pagamento. Tente novamente em instantes ou entre em contato.</div>}
    {data.payment_status === "awaiting_payment" && pix && <div className="card" style={{ maxWidth: 560 }}><h3>Pague com Pix</h3><p className="small">Copie o código abaixo e cole no app do seu banco. O pedido será confirmado automaticamente após a aprovação.</p>
      <textarea readOnly rows={4} value={pix.pix_qr_code ?? ""} aria-label="Código Pix copia e cola" /><button className="btn sm" style={{ marginTop: 8 }} onClick={async () => { await navigator.clipboard.writeText(pix.pix_qr_code ?? ""); setCopied(true); }}>{copied ? "Copiado" : "Copiar código"}</button></div>}
    <div className="tablewrap" style={{ marginTop: 24 }}><table><thead><tr><th>Item</th><th>Qtd.</th><th>Unitário</th><th>Total</th></tr></thead>
      <tbody>{(data.order_items as { id: string; product_name: string; variant_label: string; sku: string; quantity: number; unit_price_cents: number }[]).map((i) => <tr key={i.id}><td>{i.product_name}<div className="small muted">{i.variant_label} · {i.sku}</div></td><td>{i.quantity}</td><td>{formatBRL(i.unit_price_cents)}</td><td>{formatBRL(i.unit_price_cents * i.quantity)}</td></tr>)}</tbody></table></div>
    <div className="card" style={{ maxWidth: 380, marginLeft: "auto", marginTop: 16 }}>
      <div className="row-between"><span>Subtotal</span><span>{formatBRL(data.subtotal_cents)}</span></div>
      {data.discount_cents > 0 && <div className="row-between"><span>Desconto</span><span>− {formatBRL(data.discount_cents)}</span></div>}
      <div className="row-between"><span>Frete</span><span>{formatBRL(data.shipping_cents)}</span></div>
      <div className="row-between"><strong>Total</strong><strong>{formatBRL(data.total_cents)}</strong></div>
      {data.refunded_cents > 0 && <div className="row-between"><span>Reembolsado</span><span>{formatBRL(data.refunded_cents)}</span></div>}</div>
    <p className="small" style={{ marginTop: 16 }}>Entrega: {a.recipient} — {a.street}, {a.number}, {a.district}, {a.city}/{a.state}, CEP {a.zip}</p></div>;
}
