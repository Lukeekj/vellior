import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useAsync } from "../hooks/useAsync";
import { useAuth } from "../context/AuthContext";
import { useCart } from "../context/CartContext";
import { formatBRL, unitPrice } from "../lib/money";
import { Spinner } from "../components/Guards";
import { useSeo } from "../hooks/useSeo";

type Row = { id: string; sku: string; label: string; price_cents: number | null; stock: number; reserved: number; products: { name: string; slug: string; price_cents: number; sale_price_cents: number | null } };

export default function Cart() {
  useSeo("Carrinho — VELLIOR");
  const { lines, setQty, remove } = useCart();
  const { user } = useAuth();
  const nav = useNavigate();
  const [busy, setBusy] = useState<string | null>(null);
  const ids = lines.map((l) => l.variantId).join(",");
  const { data, loading } = useAsync(async () => {
    if (!lines.length) return [] as Row[];
    const { data } = await supabase.from("product_variants").select("id,sku,label,price_cents,stock,reserved,products(name,slug,price_cents,sale_price_cents)").in("id", lines.map((l) => l.variantId));
    return (data ?? []) as unknown as Row[];
  }, [ids]);

  if (loading) return <Spinner />;
  const rows = lines.map((l) => ({ l, v: data?.find((r) => r.id === l.variantId) })).filter((x) => x.v);
  const subtotal = rows.reduce((s, { l, v }) => s + unitPrice(v!.products, v!) * l.quantity, 0);
  const change = async (id: string, q: number) => { setBusy(id); try { await setQty(id, q); } finally { setBusy(null); } };

  if (!rows.length) return <div className="container empty"><h1>Seu carrinho está vazio</h1><p>Explore a loja e adicione seus favoritos.</p><Link className="btn" to="/loja">Ver produtos</Link></div>;
  return (
    <div className="container section">
      <h1>Carrinho</h1>
      <div className="tablewrap"><table>
        <thead><tr><th>Produto</th><th>Preço</th><th>Qtd.</th><th>Total</th><th><span className="sr-only">Remover</span></th></tr></thead>
        <tbody>{rows.map(({ l, v }) => {
          const unit = unitPrice(v!.products, v!); const avail = v!.stock - v!.reserved;
          return <tr key={l.variantId}>
            <td><Link to={`/produto/${v!.products.slug}`}>{v!.products.name}</Link><div className="small muted">{v!.label} · {v!.sku}</div>{avail < l.quantity && <div className="err">Estoque insuficiente ({Math.max(avail, 0)} disponível)</div>}</td>
            <td>{formatBRL(unit)}</td>
            <td><label className="sr-only" htmlFor={`q${l.variantId}`}>Quantidade</label><input id={`q${l.variantId}`} style={{ width: 70 }} type="number" min={1} max={20} value={l.quantity} disabled={busy === l.variantId} onChange={(e) => change(l.variantId, Number(e.target.value))} /></td>
            <td>{formatBRL(unit * l.quantity)}</td>
            <td><button className="btn ghost sm" onClick={() => { if (confirm("Remover este item do carrinho?")) void remove(l.variantId); }}>Remover</button></td></tr>;
        })}</tbody></table></div>
      <div className="card" style={{ maxWidth: 380, marginLeft: "auto", marginTop: 24 }}>
        <div className="row-between"><span>Subtotal</span><strong>{formatBRL(subtotal)}</strong></div>
        <p className="small muted">Frete e cupom são calculados no checkout. Valores finais são confirmados pelo servidor.</p>
        <button className="btn" style={{ width: "100%" }} onClick={() => nav(user ? "/checkout" : "/entrar?next=/checkout")}>{user ? "Finalizar compra" : "Entrar para finalizar"}</button>
      </div>
    </div>
  );
}
