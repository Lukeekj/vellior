import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useAsync } from "../hooks/useAsync";
import { useCart } from "../context/CartContext";
import { formatBRL, unitPrice } from "../lib/money";
import { Spinner } from "../components/Guards";
import { useSeo } from "../hooks/useSeo";
import { ProductCard, imageUrl, type ProductRow } from "../components/ProductCard";

type Variant = { id: string; sku: string; label: string; color: string | null; size: string | null; price_cents: number | null; stock: number; reserved: number; active: boolean };

export default function Product() {
  const { slug } = useParams();
  const { add } = useCart();
  const nav = useNavigate();
  const [sel, setSel] = useState<string | null>(null);
  const [img, setImg] = useState(0);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState("");

  const { data: p, loading } = useAsync(async () => {
    const { data } = await supabase.from("products")
      .select("*,product_images(path,alt,position),product_variants(id,sku,label,color,size,price_cents,stock,reserved,active)").eq("slug", slug ?? "").maybeSingle();
    return data;
  }, [slug]);
  const rel = useAsync(async () => p ? (await supabase.from("products").select("id,slug,name,price_cents,sale_price_cents,is_demo,product_images(path,alt,position),product_variants(stock,reserved,active)").eq("category_id", p.category_id ?? "").neq("id", p.id).limit(4)).data as ProductRow[] | null : null, [p?.id]);

  useSeo(p ? `${p.name} — VELLIOR` : "Produto não encontrado — VELLIOR", p ? `/produto/${p.slug}` : undefined);
  if (loading) return <Spinner />;
  if (!p) return <div className="container empty"><h1>Produto não encontrado</h1><Link className="btn" to="/loja">Voltar à loja</Link></div>;

  const variants = ((p.product_variants ?? []) as Variant[]).filter((v) => v.active);
  const chosen = variants.find((v) => v.id === (sel ?? (variants.length === 1 ? variants[0].id : null)));
  const avail = (v: Variant) => v.stock - v.reserved;
  const images = [...(p.product_images ?? [])].sort((a: { position: number }, b: { position: number }) => a.position - b.position);
  const price = unitPrice(p, chosen);

  async function addToCart() {
    if (!chosen) { setMsg("Selecione uma opção."); return; }
    setBusy(true);
    try { await add(chosen.id); nav("/carrinho"); } finally { setBusy(false); }
  }
  return (
    <div className="container section">
      <div className="two">
        <div className="gallery">
          {images[img] ? <img src={imageUrl(images[img].path)} alt={images[img].alt ?? p.name} /> : <div className="ph" />}
          {images.length > 1 && <div className="thumbs">{images.map((im: { path: string; alt: string | null }, i: number) => <button key={im.path} aria-label={`Foto ${i + 1}`} onClick={() => setImg(i)}><img src={imageUrl(im.path)} alt="" /></button>)}</div>}
        </div>
        <div>
          {p.is_demo && <span className="tag demo">Produto de demonstração</span>}
          <h1>{p.name}</h1>
          <p style={{ fontSize: "1.4rem" }}>{p.sale_price_cents != null && !chosen?.price_cents && <span className="old">{formatBRL(p.price_cents)}</span>}<span className="price">{formatBRL(price)}</span></p>
          {p.description && <p style={{ whiteSpace: "pre-line" }}>{p.description}</p>}
          {variants.length > 0 ? (
            <fieldset style={{ border: 0, padding: 0, margin: "20px 0" }}>
              <legend className="small" style={{ fontWeight: 600, marginBottom: 8 }}>Opções</legend>
              <div className="chips">{variants.map((v) => <button key={v.id} className="chip" aria-pressed={chosen?.id === v.id} disabled={avail(v) <= 0} onClick={() => setSel(v.id)}>{v.label}</button>)}</div>
            </fieldset>
          ) : <div className="notice">Produto indisponível no momento.</div>}
          {chosen && <p className="small muted">SKU {chosen.sku} · {avail(chosen) > 0 ? `${avail(chosen)} em estoque` : "Indisponível"}</p>}
          {(p.material || p.dimensions) && <ul className="small">{p.material && <li>Material: {p.material}</li>}{p.dimensions && <li>Dimensões: {p.dimensions}</li>}</ul>}
          <button className="btn" disabled={busy || variants.length === 0 || (!!chosen && avail(chosen) <= 0)} onClick={addToCart}>{busy ? "Adicionando…" : "Adicionar ao carrinho"}</button>
          {msg && <p className="err" role="alert">{msg}</p>}
          <p className="small muted" style={{ marginTop: 20 }}>Frete e prazo de entrega são calculados no checkout. Condições de garantia e trocas: consulte as políticas da loja.</p>
        </div>
      </div>
      {(rel.data?.length ?? 0) > 0 && <section style={{ marginTop: 64 }}><h2>Você também pode gostar</h2><div className="grid">{rel.data!.map((r) => <ProductCard key={r.id} p={r} />)}</div></section>}
    </div>
  );
}
