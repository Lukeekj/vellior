import { Link } from "react-router-dom";
import { supabase } from "../lib/supabase";
import { useAsync } from "../hooks/useAsync";
import { ProductCard, type ProductRow } from "../components/ProductCard";
import { Spinner } from "../components/Guards";
import { RefreshIcon, ShieldIcon, TruckIcon } from "../components/Icons";

const SEL = "id,slug,name,price_cents,sale_price_cents,is_demo,product_images(path,alt,position),product_variants(stock,reserved,active)";

export default function Home() {
  const news = useAsync(async () => (await supabase.from("products").select(SEL).order("created_at", { ascending: false }).limit(8)).data as ProductRow[] | null);
  const offers = useAsync(async () => (await supabase.from("products").select(SEL).not("sale_price_cents", "is", null).limit(4)).data as ProductRow[] | null);
  const cats = useAsync(async () => (await supabase.from("categories").select("slug,name,description").order("position")).data ?? []);
  return (
    <>
      <section className="hero">
        <div className="container">
          <h1>Elegância em cada detalhe.</h1>
          <p>Relógios, semijoias e acessórios selecionados para compor o seu estilo.</p>
          <Link className="btn" to="/loja">Explorar a loja</Link>
        </div>
      </section>
      <section className="section container" aria-labelledby="cats">
        <h2 id="cats">Categorias</h2>
        {cats.loading ? <Spinner /> : (cats.data?.length ?? 0) === 0 ? <p className="muted">Nenhuma categoria publicada ainda.</p> :
          <div className="grid">{cats.data!.map((c) => <Link key={c.slug} className="card" to={`/loja?categoria=${c.slug}`} style={{ textDecoration: "none" }}><h3>{c.name}</h3><p className="muted small">{c.description}</p></Link>)}</div>}
      </section>
      <section className="section container" aria-labelledby="news">
        <h2 id="news">Novidades</h2>
        {news.loading ? <Spinner /> : (news.data?.length ?? 0) === 0 ? <div className="empty">Os primeiros produtos serão publicados em breve.</div> :
          <div className="grid">{news.data!.map((p) => <ProductCard key={p.id} p={p} />)}</div>}
      </section>
      {(offers.data?.length ?? 0) > 0 && (
        <section className="section container" aria-labelledby="off"><h2 id="off">Ofertas</h2><div className="grid">{offers.data!.map((p) => <ProductCard key={p.id} p={p} />)}</div></section>
      )}
      <section className="section container" aria-label="Benefícios">
        <div className="benefits">
          <div><TruckIcon /><h3>Entrega</h3><p className="muted small">Prazo e frete calculados no checkout.</p></div>
          <div><RefreshIcon /><h3>Trocas</h3><p className="muted small">Política de trocas conforme a legislação de consumo.</p></div>
          <div><ShieldIcon /><h3>Compra segura</h3><p className="muted small">Pagamento processado pelo Mercado Pago.</p></div>
        </div>
      </section>
    </>
  );
}
