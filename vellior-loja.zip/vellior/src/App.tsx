import { Route, Routes } from "react-router-dom";
import Layout from "./components/Layout";
import { RequireAuth, RequireStaff } from "./components/Guards";
import Home from "./pages/Home";
import Catalog from "./pages/Catalog";
import Product from "./pages/Product";
import Cart from "./pages/Cart";
import { AuthCallback, Forgot, Login, Reset, Signup } from "./pages/Auth";
import { Checkout } from "./pages/Checkout";
import { Account, OrderDetail, Orders } from "./pages/Account";
import { Cookies, NotFound, Privacy, Terms } from "./pages/Static";
import AdminLayout from "./pages/admin/AdminLayout";
import Dashboard from "./pages/admin/Dashboard";
import Products from "./pages/admin/Products";
import AdminOrders from "./pages/admin/Orders";
import Stock from "./pages/admin/Stock";
import Coupons from "./pages/admin/Coupons";
import Payments from "./pages/admin/Payments";
import Categories from "./pages/admin/Categories";
import Settings from "./pages/admin/Settings";

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="loja" element={<Catalog />} />
        <Route path="produto/:slug" element={<Product />} />
        <Route path="carrinho" element={<Cart />} />
        <Route path="entrar" element={<Login />} />
        <Route path="criar-conta" element={<Signup />} />
        <Route path="esqueci-senha" element={<Forgot />} />
        <Route path="redefinir-senha" element={<Reset />} />
        <Route path="auth/callback" element={<AuthCallback />} />
        <Route path="checkout" element={<RequireAuth><Checkout /></RequireAuth>} />
        <Route path="conta" element={<RequireAuth><Account /></RequireAuth>} />
        <Route path="conta/pedidos" element={<RequireAuth><Orders /></RequireAuth>} />
        <Route path="conta/pedidos/:id" element={<RequireAuth><OrderDetail /></RequireAuth>} />
        <Route path="termos" element={<Terms />} />
        <Route path="privacidade" element={<Privacy />} />
        <Route path="cookies" element={<Cookies />} />
        <Route path="*" element={<NotFound />} />
      </Route>
      <Route path="admin" element={<RequireStaff><AdminLayout /></RequireStaff>}>
        <Route index element={<Dashboard />} />
        <Route path="produtos" element={<Products />} />
        <Route path="categorias" element={<Categories />} />
        <Route path="pedidos" element={<AdminOrders />} />
        <Route path="estoque" element={<Stock />} />
        <Route path="cupons" element={<Coupons />} />
        <Route path="pagamentos" element={<Payments />} />
        <Route path="configuracoes" element={<Settings />} />
      </Route>
    </Routes>
  );
}
