import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase, supabaseConfigured } from "../lib/supabase";

type Role = "customer" | "admin" | "operator";
type Ctx = { user: User | null; session: Session | null; roles: Role[]; isAdmin: boolean; isStaff: boolean; loading: boolean; signOut: () => Promise<void> };
const AuthCtx = createContext<Ctx>({ user: null, session: null, roles: [], isAdmin: false, isStaff: false, loading: true, signOut: async () => {} });

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!supabaseConfigured) { setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); setLoading(false); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => setSession(s));
    return () => sub.subscription.unsubscribe();
  }, []);

  // Papéis vêm do banco (tabela protegida por RLS). Isto é só para a UI: a autorização real está no RLS/RPC.
  useEffect(() => {
    if (!session?.user) { setRoles([]); return; }
    supabase.from("user_roles").select("role").eq("user_id", session.user.id).then(({ data }) =>
      setRoles((data ?? []).map((r) => r.role as Role)));
  }, [session?.user?.id]);

  const value: Ctx = {
    user: session?.user ?? null, session, roles, loading,
    isAdmin: roles.includes("admin"), isStaff: roles.includes("admin") || roles.includes("operator"),
    signOut: async () => { await supabase.auth.signOut(); },
  };
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>;
}
export const useAuth = () => useContext(AuthCtx);
