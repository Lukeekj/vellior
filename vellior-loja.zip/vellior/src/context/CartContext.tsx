import { createContext, useCallback, useContext, useEffect, useState, type ReactNode } from "react";
import { supabase, supabaseConfigured } from "../lib/supabase";
import { useAuth } from "./AuthContext";

export type CartLine = { variantId: string; quantity: number };
type Ctx = { lines: CartLine[]; count: number; add: (v: string, q?: number) => Promise<void>; setQty: (v: string, q: number) => Promise<void>; remove: (v: string) => Promise<void>; reload: () => Promise<void> };
const KEY = "vellior.cart.v1";
const CartCtx = createContext<Ctx>({ lines: [], count: 0, add: async () => {}, setQty: async () => {}, remove: async () => {}, reload: async () => {} });
const clamp = (q: number) => Math.max(1, Math.min(20, Math.floor(q) || 1));

function readLocal(): CartLine[] {
  try { const a = JSON.parse(localStorage.getItem(KEY) ?? "[]"); return Array.isArray(a) ? a.filter((l) => typeof l?.variantId === "string").map((l) => ({ variantId: l.variantId, quantity: clamp(l.quantity) })) : []; }
  catch { return []; }
}
const writeLocal = (l: CartLine[]) => { try { localStorage.setItem(KEY, JSON.stringify(l)); } catch { /* ignora */ } };

export function CartProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [lines, setLines] = useState<CartLine[]>(readLocal);

  const reload = useCallback(async () => {
    if (!user || !supabaseConfigured) { setLines(readLocal()); return; }
    const { data } = await supabase.from("cart_items").select("variant_id, quantity");
    setLines((data ?? []).map((r) => ({ variantId: r.variant_id, quantity: r.quantity })));
  }, [user?.id]);

  // Ao autenticar: mescla o carrinho anônimo no carrinho da conta e limpa o local (carrinho preservado no login).
  useEffect(() => {
    (async () => {
      if (user && supabaseConfigured) {
        const local = readLocal();
        if (local.length) {
          const { data: existing } = await supabase.from("cart_items").select("variant_id, quantity");
          const map = new Map((existing ?? []).map((r) => [r.variant_id, r.quantity as number]));
          for (const l of local) map.set(l.variantId, clamp((map.get(l.variantId) ?? 0) + l.quantity));
          await supabase.from("cart_items").upsert([...map].map(([variant_id, quantity]) => ({ user_id: user.id, variant_id, quantity })));
          writeLocal([]);
        }
      }
      await reload();
    })();
  }, [user?.id, reload]);

  const add = async (variantId: string, q = 1) => {
    const cur = lines.find((l) => l.variantId === variantId)?.quantity ?? 0;
    return setQty(variantId, cur + q);
  };
  const setQty = async (variantId: string, q: number) => {
    const quantity = clamp(q);
    if (user) await supabase.from("cart_items").upsert({ user_id: user.id, variant_id: variantId, quantity });
    else { const next = [...lines.filter((l) => l.variantId !== variantId), { variantId, quantity }]; writeLocal(next); }
    await reload();
  };
  const remove = async (variantId: string) => {
    if (user) await supabase.from("cart_items").delete().eq("variant_id", variantId);
    else writeLocal(lines.filter((l) => l.variantId !== variantId));
    await reload();
  };
  return <CartCtx.Provider value={{ lines, count: lines.reduce((s, l) => s + l.quantity, 0), add, setQty, remove, reload }}>{children}</CartCtx.Provider>;
}
export const useCart = () => useContext(CartCtx);
