import { useEffect } from "react";

export function useSeo(title: string, canonicalPath?: string) {
  useEffect(() => {
    document.title = title;
    let link = document.querySelector<HTMLLinkElement>('link[rel="canonical"]');
    if (canonicalPath) {
      if (!link) { link = document.createElement("link"); link.rel = "canonical"; document.head.appendChild(link); }
      link.href = location.origin + canonicalPath;
    } else link?.remove();
  }, [title, canonicalPath]);
}
