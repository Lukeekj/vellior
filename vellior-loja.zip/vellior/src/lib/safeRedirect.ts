/** Aceita apenas caminhos internos ("/x"). Bloqueia "//host", "http://", "\\", javascript: etc. (open redirect). */
export function safeNext(next: string | null | undefined, fallback = "/"): string {
  if (!next) return fallback;
  if (!next.startsWith("/") || next.startsWith("//") || next.includes("\\") || /[\u0000-\u001f]/.test(next)) return fallback;
  return next;
}
