export function formatBRL(cents: number): string {
  return new Intl.NumberFormat("pt-BR", { style: "currency", currency: "BRL" }).format(cents / 100);
}

/** Converte "12,50" / "12.50" para centavos. Retorna null se inválido. */
export function parseBRLToCents(input: string): number | null {
  const clean = input.trim().replace(/\s/g, "").replace(/^R\$/, "");
  if (!/^\d{1,9}([.,]\d{1,2})?$/.test(clean.replace(/\.(?=\d{3}(\D|$))/g, ""))) return null;
  const n = Number(clean.replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", "."));
  return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : null;
}

export function unitPrice(p: { price_cents: number; sale_price_cents: number | null }, v?: { price_cents: number | null }): number {
  if (v && v.price_cents != null) return v.price_cents;
  return p.sale_price_cents ?? p.price_cents;
}
