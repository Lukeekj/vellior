import { z } from "zod";

export const signupSchema = z
  .object({
    fullName: z.string().trim().min(2, "Informe seu nome completo.").max(120),
    email: z.string().trim().toLowerCase().email("E-mail inválido.").max(254),
    password: z
      .string()
      .min(8, "A senha deve ter ao menos 8 caracteres.")
      .max(72, "Senha muito longa.")
      .regex(/[A-Za-z]/, "Inclua ao menos uma letra.")
      .regex(/\d/, "Inclua ao menos um número."),
    confirm: z.string(),
    acceptTerms: z.literal(true, { errorMap: () => ({ message: "É necessário aceitar os termos e a política de privacidade." }) }),
  })
  .refine((d) => d.password === d.confirm, { message: "As senhas não coincidem.", path: ["confirm"] });

export const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("E-mail inválido."),
  password: z.string().min(1, "Informe a senha.").max(72),
});

export const addressSchema = z.object({
  recipient: z.string().trim().min(2, "Informe o destinatário.").max(120),
  zip: z.string().transform((s) => s.replace(/\D/g, "")).pipe(z.string().regex(/^\d{8}$/, "CEP inválido.")),
  street: z.string().trim().min(2, "Informe a rua.").max(160),
  number: z.string().trim().min(1, "Informe o número.").max(20),
  complement: z.string().trim().max(80).optional().or(z.literal("")),
  district: z.string().trim().min(2, "Informe o bairro.").max(80),
  city: z.string().trim().min(2, "Informe a cidade.").max(80),
  state: z.string().trim().toUpperCase().regex(/^[A-Z]{2}$/, "UF inválida."),
});

export function slugify(s: string): string {
  return s.normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
