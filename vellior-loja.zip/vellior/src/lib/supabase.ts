import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const anon = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

export const supabaseConfigured = Boolean(url && anon);

// Somente a anon key (pública por design). A segurança real está no RLS e nas funções do banco.
export const supabase = createClient(url ?? "http://localhost:54321", anon ?? "anon-not-configured", {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true, flowType: "pkce" },
});

export const socialProviders = {
  google: import.meta.env.VITE_AUTH_GOOGLE_ENABLED === "true",
  apple: import.meta.env.VITE_AUTH_APPLE_ENABLED === "true",
};
