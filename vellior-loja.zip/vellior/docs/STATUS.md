# Status da implementação (verificado em 14/10/2026)

## 1. Implementado e testado
- **Banco**: esquema, RLS forçada em todas as tabelas, privilégios mínimos, auditoria imutável (`audit_log` append-only, até para superusuário). `bash tests/db/run.sh` → 55 verificações PASS.
- **Autorização**: novo usuário só recebe `customer`; cliente não se promove a admin (insert/update/RPC), não lê cupons, custos, auditoria, eventos de pagamento nem pedidos alheios (IDOR); não escreve em `orders`.
- **Pedido/estoque**: totais calculados no servidor; cupom (percentual/fixo, validade, mínimo, limite, sem total negativo); reserva atômica; idempotência; snapshot histórico imune a mudanças no catálogo; expiração libera reserva. Concorrência: 10 compradores/1 unidade → exatamente 1 venda (`tests/db/concurrency.test.sh`).
- **Pagamentos (lógica de banco)**: `apply_payment_event` idempotente, transições válidas, reembolso parcial/total, histórico financeiro.
- **Front**: build TypeScript OK; 22 testes unitários (validação, dinheiro, redirecionamento seguro contra open-redirect).

## 2. Implementado, aguardando credenciais/configuração (NÃO testado contra serviços reais)
- Login **Google** e **Apple**: botões só funcionam após configurar provedores no Supabase (`docs/AUTENTICACAO.md`); antes disso mostram "ainda não configurado".
- **Mercado Pago**: `create-payment` (Pix), `mp-webhook` (verificação de assinatura + consulta do status real), `admin-payments` (status mascarado, teste de conectividade, reembolso). Métodos nascem **desabilitados**. Falta rodar o fluxo ponta a ponta no sandbox.
- E-mails de cadastro/recuperação de senha: usam o SMTP do Supabase (configure SMTP próprio em produção).

## 3. Ainda não implementado
- **Cartão de crédito no front** (tokenização com MP.js); a Edge Function já aceita o token.
- **Frete por transportadora** (hoje: regra fixa configurável + frete grátis acima de valor).
- **E-mails transacionais de pedido** (criado/pago/enviado/rastreio).
- Painel: CMS de banners/textos, tela de clientes, upload de imagens de produto, relatórios exportáveis, edição de dados comerciais.
- LGPD operacional: exportação/anonimização de dados do cliente; textos jurídicos (as páginas são **provisórias** e exigem revisão jurídica).
- Alertas automáticos (falhas de login, erros de integração) e rate limiting próprio nas Edge Functions (hoje: limites do Supabase Auth + validação no servidor).
- Testes ponta a ponta de navegador e testes automatizados contra o Auth real (RLS foi testada em Postgres com um stub do Supabase).
- Code-splitting do bundle (528 kB).

## 4. Falhou nos testes e precisa de correção
Nenhum teste falhando no momento. Isso **não** significa que a loja esteja segura para produção: ver itens 2 e 3 e o checklist de `docs/SEGURANCA.md`.
