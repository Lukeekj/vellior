# Criar o primeiro administrador (processo controlado)
Não existe cadastro público de admin nem e-mail/senha fixos.
1. Crie sua conta normalmente em `/criar-conta` e confirme o e-mail.
2. No Supabase → SQL Editor (conexão privilegiada), execute:
```sql
select public.grant_admin((select id from auth.users where email = 'SEU_EMAIL'));
```
`grant_admin` só é executável por `service_role`/SQL Editor; clientes recebem "permission denied". A concessão fica registrada em `audit_log`.
3. Faça logout/login e acesse `/admin`. Papel `operator` (pedidos/logística) é concedido da mesma forma com `insert into user_roles(user_id, role) values (..., 'operator')`.
