# Autenticação
**URLs** (Supabase → Authentication → URL Configuration): Site URL = domínio da loja; Redirect URLs = `https://SEU_DOMINIO/auth/callback` (+ localhost em dev). O front só aceita caminhos internos em `next` (`src/lib/safeRedirect.ts`).
**E-mail/senha**: habilite "Confirm email"; defina política de senha mínima; configure SMTP próprio. Limites de tentativas: ajuste Rate Limits no painel do Supabase.
**Google**: Google Cloud Console → Credenciais → ID do cliente OAuth (Web). Origem: domínio da loja. Redirect URI: `https://<ref>.supabase.co/auth/v1/callback`. Cole Client ID/Secret em Supabase → Auth → Providers → Google. No front defina `VITE_AUTH_GOOGLE_ENABLED=true`.
**Apple**: Apple Developer → Services ID + chave "Sign in with Apple"; Return URL `https://<ref>.supabase.co/auth/v1/callback`. Configure em Providers → Apple (o client secret JWT expira em até 6 meses: renove). No front: `VITE_AUTH_APPLE_ENABLED=true`.
Não vincule contas por e-mail igual sem verificação: mantenha "Allow manual linking" desativado e use o fluxo seguro do Supabase.
