# Pagamentos — Mercado Pago
**Secrets (Supabase → Edge Functions → Secrets; nunca no front):** `MP_ACCESS_TOKEN` (credencial de teste ou produção), `MP_WEBHOOK_SECRET`, `MP_ENV` (`sandbox`|`production`), `SITE_URL` (origens permitidas, separadas por vírgula).
**Deploy:** `supabase functions deploy create-payment mp-webhook admin-payments` (webhook sem verificação JWT: `--no-verify-jwt`, a autenticação é a assinatura `x-signature`).
**Webhook:** no painel do Mercado Pago, URL `https://<ref>.functions.supabase.co/mp-webhook`, evento "Pagamentos", copie a chave secreta para `MP_WEBHOOK_SECRET`.
**Habilitar:** painel → Pagamentos → ativar Pix (tabela `payment_methods_config`). Use "Testar conexão" (retorna só ok/status, nunca o token).
**Ordem segura:** (1) sandbox: Pix de teste → webhook → pedido `paid`; recusa; expiração; reembolso. (2) Só então produção, com `MP_ENV=production` e token de produção.
**Garantias:** valor vem do pedido no banco; status só muda por `apply_payment_event` após consulta da API do provedor; eventos duplicados são ignorados; transições inválidas descartadas; pagamento aprovado com valor divergente não é aceito.
**Limitação:** pagamento Pix aprovado após o pedido expirar está coberto no banco (o webhook aplica a transição), mas o cenário real deve ser validado no sandbox.
