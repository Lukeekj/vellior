# Segurança
## Modelo
- RLS **forçada** em todas as tabelas; `revoke all` para `anon/authenticated` e concessões explícitas (`0002_rls.sql`).
- Leitura pública: apenas categorias/produtos/variantes/imagens publicados e `store_settings.is_public`.
- Cliente: lê/escreve só os próprios endereços/carrinho; lê só os próprios pedidos; **nenhuma** escrita direta em pedidos/pagamentos/estoque/papéis.
- Operações críticas via funções `SECURITY DEFINER` com `search_path` fixo: `quote_cart`, `create_order`, `apply_payment_event` (só `service_role`), `admin_*`.
- Custos (`product_costs`), cupons, auditoria e eventos de pagamento: só admin.
- Auditoria imutável de produtos, cupons, papéis, configurações, estoque e ações financeiras.
- Edge Functions: sessão validada no servidor, entrada validada com zod, papel admin verificado no banco, CORS restrito a `SITE_URL`, erros genéricos com `correlation` id.
- Front: sem segredos; CSP/HSTS/X-Frame-Options/Referrer-Policy em `vercel.json` e `public/_headers`; redirecionamentos validados.
## Checklist antes da produção
- [ ] Revisar jurídica dos Termos, Privacidade e Cookies (hoje provisórios)
- [ ] SMTP próprio + confirmação de e-mail ativa + rate limits do Auth revisados
- [ ] Google/Apple configurados e testados (ou botões ocultos)
- [ ] 1º admin criado por `grant_admin`; nenhum admin de teste
- [ ] Sandbox Mercado Pago: Pix aprovado, recusado, expirado, reembolso, webhook repetido e com assinatura inválida
- [ ] Só então `MP_ENV=production` e token de produção
- [ ] `release_expired_reservations` agendada (pg_cron)
- [ ] Backups/PITR habilitados no Supabase e restauração testada
- [ ] `npm audit` sem vulnerabilidades altas; dependências atualizadas
- [ ] Confirmar que `service_role` e `MP_*` não aparecem no bundle (`grep -r` em `dist/`)
- [ ] Domínio com HTTPS e cabeçalhos ativos (testar em securityheaders.com)
- [ ] Teste de invasão básico / revisão de políticas RLS por segunda pessoa
- [ ] Substituir produtos de demonstração (`is_demo`) por reais
Procedimento de incidente: revogar tokens (Supabase/MP), rotacionar `MP_ACCESS_TOKEN`/`MP_WEBHOOK_SECRET`, consultar `audit_log` e `payment_events`, restaurar backup se necessário.
Nenhuma garantia de invulnerabilidade: o objetivo é reduzir riscos, detectar e permitir recuperação.
