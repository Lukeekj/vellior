import { describe, expect, it } from "vitest";
import { formatBRL, parseBRLToCents, unitPrice } from "../src/lib/money";
import { safeNext } from "../src/lib/safeRedirect";
import { addressSchema, loginSchema, signupSchema, slugify } from "../src/lib/validation";
import { fromCents, mapApprovedWithRefund, mapMpStatus, toCents, verifyMpSignature } from "../supabase/functions/_shared/mp";

describe("dinheiro", () => {
  it("formata BRL", () => expect(formatBRL(1234500).replace(/\s/g, " ")).toBe("R$ 12.345,00".replace(/\s/g, " ")));
  it("converte texto em centavos", () => {
    expect(parseBRLToCents("12,50")).toBe(1250);
    expect(parseBRLToCents("R$ 1.299,90")).toBe(129990);
    expect(parseBRLToCents("abc")).toBeNull();
    expect(parseBRLToCents("-5")).toBeNull();
    expect(parseBRLToCents("1,234")).toBeNull();
  });
  it("preço unitário: variante > promoção > preço", () => {
    expect(unitPrice({ price_cents: 100, sale_price_cents: 80 })).toBe(80);
    expect(unitPrice({ price_cents: 100, sale_price_cents: 80 }, { price_cents: 90 })).toBe(90);
    expect(unitPrice({ price_cents: 100, sale_price_cents: null }, { price_cents: null })).toBe(100);
  });
  it("centavos <-> reais sem erro de ponto flutuante", () => { expect(toCents(19.9)).toBe(1990); expect(toCents(0.1 + 0.2)).toBe(30); expect(fromCents(1990)).toBe(19.9); });
});

describe("redirecionamento seguro (open redirect)", () => {
  it("aceita caminhos internos", () => expect(safeNext("/checkout?x=1")).toBe("/checkout?x=1"));
  it.each(["//evil.com", "https://evil.com", "javascript:alert(1)", "/\\evil.com", "evil", "/a\nb"])("bloqueia %s", (u) => expect(safeNext(u)).toBe("/"));
  it("usa fallback", () => expect(safeNext(null, "/conta")).toBe("/conta"));
});

describe("validação", () => {
  const ok = { fullName: "Maria Souza", email: "MARIA@EXEMPLO.com", password: "senha1234", confirm: "senha1234", acceptTerms: true as const };
  it("cadastro válido normaliza e-mail", () => expect(signupSchema.parse(ok).email).toBe("maria@exemplo.com"));
  it("rejeita senha fraca, divergente e sem termos", () => {
    expect(signupSchema.safeParse({ ...ok, password: "abc", confirm: "abc" }).success).toBe(false);
    expect(signupSchema.safeParse({ ...ok, password: "somenteletras", confirm: "somenteletras" }).success).toBe(false);
    expect(signupSchema.safeParse({ ...ok, confirm: "outra1234" }).success).toBe(false);
    expect(signupSchema.safeParse({ ...ok, acceptTerms: false }).success).toBe(false);
  });
  it("login exige e-mail válido", () => expect(loginSchema.safeParse({ email: "x", password: "y" }).success).toBe(false));
  it("endereço normaliza CEP e UF", () => {
    const a = addressSchema.parse({ recipient: "Ana Lima", zip: "01001-000", street: "Rua A", number: "10", district: "Centro", city: "São Paulo", state: "sp" });
    expect(a.zip).toBe("01001000"); expect(a.state).toBe("SP");
  });
  it("slugify remove acentos", () => expect(slugify("Colares & Correntes Ação")).toBe("colares-correntes-acao"));
});

describe("Mercado Pago: status", () => {
  it("mapeia status", () => {
    expect(mapMpStatus("approved")).toBe("paid"); expect(mapMpStatus("pending")).toBe("awaiting_payment");
    expect(mapMpStatus("in_process")).toBe("processing"); expect(mapMpStatus("rejected")).toBe("refused");
    expect(mapMpStatus("cancelled")).toBe("cancelled"); expect(mapMpStatus("refunded")).toBe("refunded"); expect(mapMpStatus("charged_back")).toBe("refunded");
  });
  it("reembolso parcial/total vindo como approved", () => {
    expect(mapApprovedWithRefund("approved", 10, 100)).toBe("partially_refunded");
    expect(mapApprovedWithRefund("approved", 100, 100)).toBe("refunded");
    expect(mapApprovedWithRefund("approved", 0, 100)).toBe("paid");
  });
});

describe("Mercado Pago: assinatura do webhook", () => {
  const secret = "segredo-de-teste";
  async function sign(dataId: string, reqId: string, ts: string) {
    const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(`id:${dataId.toLowerCase()};request-id:${reqId};ts:${ts};`));
    return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }
  const now = 1_800_000_000_000, ts = String(now);
  it("aceita assinatura válida", async () => {
    const v1 = await sign("123", "req-1", ts);
    expect(await verifyMpSignature({ secret, signatureHeader: `ts=${ts},v1=${v1}`, requestId: "req-1", dataId: "123", nowMs: now })).toBe(true);
  });
  it("rejeita assinatura forjada, id adulterado, segredo errado e cabeçalho ausente", async () => {
    const v1 = await sign("123", "req-1", ts);
    expect(await verifyMpSignature({ secret, signatureHeader: `ts=${ts},v1=${"0".repeat(64)}`, requestId: "req-1", dataId: "123", nowMs: now })).toBe(false);
    expect(await verifyMpSignature({ secret, signatureHeader: `ts=${ts},v1=${v1}`, requestId: "req-1", dataId: "999", nowMs: now })).toBe(false);
    expect(await verifyMpSignature({ secret: "outro", signatureHeader: `ts=${ts},v1=${v1}`, requestId: "req-1", dataId: "123", nowMs: now })).toBe(false);
    expect(await verifyMpSignature({ secret, signatureHeader: null, requestId: "req-1", dataId: "123", nowMs: now })).toBe(false);
  });
  it("rejeita repetição fora da janela de 10 minutos (replay)", async () => {
    const v1 = await sign("123", "req-1", ts);
    expect(await verifyMpSignature({ secret, signatureHeader: `ts=${ts},v1=${v1}`, requestId: "req-1", dataId: "123", nowMs: now + 11 * 60 * 1000 })).toBe(false);
  });
});
