#!/usr/bin/env bash
# 10 compradores simultâneos disputando a ÚLTIMA unidade: exatamente 1 deve ter sucesso.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; BIN=/usr/lib/postgresql/16/bin
D=$(mktemp -d); chmod 777 "$D"; PGU=${PGTEST_USER:-pgtest}
id "$PGU" >/dev/null 2>&1 || useradd -m "$PGU"
run() { su "$PGU" -c "$*"; }
run "$BIN/initdb -D $D/data -A trust >/dev/null"
run "$BIN/pg_ctl -D $D/data -o '-p 54398 -k $D -c max_connections=50' -l $D/log -w start >/dev/null"
trap "run \"$BIN/pg_ctl -D $D/data -m immediate stop >/dev/null\" || true" EXIT
P="psql -h $D -p 54398 -U $PGU -v ON_ERROR_STOP=1 -q -t -A"
run "$BIN/createdb -h $D -p 54398 vc"; chmod -R a+rX "$ROOT"
run "$P -d vc -f $ROOT/tests/db/supabase_stub.sql"
for f in "$ROOT"/supabase/migrations/*.sql; do run "$P -d vc -f $f"; done
run "$P -d vc" <<'SQL'
insert into products (id, slug, name, price_cents, published) values ('90000000-0000-0000-0000-000000000001','p','Produto Demo',10000,true);
insert into product_variants (id, product_id, sku, label, stock) values ('a0000000-0000-0000-0000-000000000001','90000000-0000-0000-0000-000000000001','S1','U',1);
do $$ declare i int; u uuid; begin for i in 1..10 loop
  u := ('00000000-0000-0000-0000-0000000001' || lpad(i::text,2,'0'))::uuid;
  insert into auth.users (id, raw_user_meta_data) values (u, '{"full_name":"Comprador"}');
  insert into addresses (id, user_id, recipient, zip, street, number, district, city, state) values (u, u, 'Comprador X','01001000','Rua','1','Centro','SP','SP');
  insert into cart_items values (u, 'a0000000-0000-0000-0000-000000000001', 1);
end loop; end $$;
SQL
for i in $(seq -w 1 10); do
  U="00000000-0000-0000-0000-0000000001$i"
  ( run "$P -d vc -c \"set request.jwt.claim.sub='$U'; set role authenticated; select create_order('$U'::uuid, null, 'idem-conc-$i');\"" >/dev/null 2>"$D/err$i" && echo ok >"$D/res$i" || echo fail >"$D/res$i" ) &
done
wait
OK=$(cat $D/res* | grep -c ok || true); FAIL=$(cat $D/res* | grep -c fail || true)
ORDERS=$(run "$P -d vc -c 'select count(*) from orders'"); RES=$(run "$P -d vc -c 'select reserved from product_variants'")
echo "sucessos=$OK falhas=$FAIL pedidos=$ORDERS reservado=$RES"
if [ "$OK" = 1 ] && [ "$ORDERS" = 1 ] && [ "$RES" = 1 ]; then echo "PASS última unidade vendida uma única vez sob concorrência"; else echo "FAIL concorrência"; exit 1; fi
