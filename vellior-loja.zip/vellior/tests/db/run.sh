#!/usr/bin/env bash
# Sobe um Postgres temporário, aplica as migrações e roda os testes SQL. Requer binários do PostgreSQL 16.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BIN=/usr/lib/postgresql/16/bin
D=$(mktemp -d); chmod 777 "$D"
PGU=${PGTEST_USER:-pgtest}
id "$PGU" >/dev/null 2>&1 || useradd -m "$PGU"
run() { su "$PGU" -c "$*"; }
run "$BIN/initdb -D $D/data -A trust >/dev/null"
run "$BIN/pg_ctl -D $D/data -o '-p 54399 -k $D' -l $D/log -w start >/dev/null"
trap "run \"$BIN/pg_ctl -D $D/data -m immediate stop >/dev/null\" || true" EXIT
P="psql -h $D -p 54399 -U $PGU -v ON_ERROR_STOP=1 -q"
run "$BIN/createdb -h $D -p 54399 vt"
chmod -R a+rX "$ROOT"
run "$P -d vt -f $ROOT/tests/db/supabase_stub.sql"
for f in "$ROOT"/supabase/migrations/*.sql; do run "$P -d vt -f $f"; done
echo "== migrações aplicadas =="
run "$P -d vt -f $ROOT/tests/db/security.test.sql" 2>&1 | grep -E "PASS|FAIL|ERROR|^psql" || true

# seed de demonstração aplicado em banco separado (não interfere nas contagens dos testes)
run "$BIN/createdb -h $D -p 54399 vs"
run "$P -d vs -f $ROOT/tests/db/supabase_stub.sql" 2>/dev/null || true
for f in "$ROOT"/supabase/migrations/*.sql; do run "$P -d vs -f $f" >/dev/null; done
if run "$P -d vs -f $ROOT/supabase/seed.sql" >/dev/null 2>&1; then echo "PASS seed de demonstração aplica sem erros"; else echo "FAIL seed de demonstração"; fi
