-- Testes de segurança/integridade do banco (RLS, pedidos, estoque, cupons, pagamentos). Saída: linhas PASS/FAIL.
create function t_pass(_name text, _ok boolean) returns void language plpgsql as $$
begin raise notice '% %', case when _ok then 'PASS' else 'FAIL' end, _name; end $$;

-- executa SQL e verifica que ele FALHA com mensagem contendo _pat
create function t_denied(_name text, _sql text, _pat text) returns void language plpgsql as $$
begin
  begin execute _sql; perform t_pass(_name || ' (deveria falhar)', false);
  exception when others then perform t_pass(_name, sqlerrm ilike '%' || _pat || '%' or sqlstate = '42501');
  end;
end $$;

create function as_user(_u uuid) returns void language plpgsql as $$
begin perform set_config('request.jwt.claim.sub', _u::text, false); execute 'set role authenticated'; end $$;
create function as_service() returns void language plpgsql as $$
begin execute 'reset role'; execute 'set role service_role'; end $$;
create function as_pg() returns void language plpgsql as $$
begin execute 'reset role'; perform set_config('request.jwt.claim.sub', '', false); end $$;

-- ===== Seed =====
insert into auth.users (id, email, raw_user_meta_data) values
 ('00000000-0000-0000-0000-00000000000a', 'a@t.com', '{"full_name":"Cliente A","accepted_terms":"true"}'),
 ('00000000-0000-0000-0000-00000000000b', 'b@t.com', '{"full_name":"Cliente B"}'),
 ('00000000-0000-0000-0000-0000000000ad', 'adm@t.com', '{"full_name":"Admin"}');
select grant_admin('00000000-0000-0000-0000-0000000000ad');

insert into categories (id, slug, name, published) values ('c0000000-0000-0000-0000-000000000001','aneis','Anéis', true);
insert into products (id, slug, name, category_id, price_cents, sale_price_cents, published, is_demo) values
 ('90000000-0000-0000-0000-000000000001','anel-demo','Anel DEMO','c0000000-0000-0000-0000-000000000001', 10000, null, true, true),
 ('90000000-0000-0000-0000-000000000002','rascunho','Rascunho','c0000000-0000-0000-0000-000000000001', 5000, null, false, true);
insert into product_costs values ('90000000-0000-0000-0000-000000000001', 4000);
insert into product_variants (id, product_id, sku, label, stock) values
 ('a0000000-0000-0000-0000-000000000001','90000000-0000-0000-0000-000000000001','DEMO-1','Único', 1),
 ('a0000000-0000-0000-0000-000000000002','90000000-0000-0000-0000-000000000001','DEMO-2','Grande', 10);
insert into coupons (code, kind, value, min_subtotal_cents, max_uses) values
 ('OFF10','percent',10,0,1), ('MIN500','fixed',500,50000,null), ('VELHO','percent',10,0,null);
update coupons set expires_at = now() - interval '1 day' where code = 'VELHO';
insert into store_settings (key, value, is_public) values ('shipping', '{"flat_cents":2000,"free_over_cents":50000}', false);
insert into addresses (id, user_id, recipient, zip, street, number, district, city, state) values
 ('d0000000-0000-0000-0000-00000000000a','00000000-0000-0000-0000-00000000000a','Ana Alves','01001000','Rua X','1','Centro','São Paulo','SP'),
 ('d0000000-0000-0000-0000-00000000000b','00000000-0000-0000-0000-00000000000b','Beto Braga','01001000','Rua Y','2','Centro','São Paulo','SP');

-- ===== Papéis e perfis =====
select t_pass('trigger criou perfil e papel customer, não admin',
  (select count(*) from user_roles where user_id = '00000000-0000-0000-0000-00000000000a' and role = 'customer') = 1
  and not has_role('00000000-0000-0000-0000-00000000000a', 'admin'));
select t_pass('consentimento de termos registrado',
  (select accepted_terms_at is not null from profiles where id = '00000000-0000-0000-0000-00000000000a'));

select as_user('00000000-0000-0000-0000-00000000000a');
select t_denied('cliente NÃO pode se promover a admin', $$insert into user_roles (user_id, role) values ('00000000-0000-0000-0000-00000000000a','admin')$$, 'permission denied');
select t_denied('cliente NÃO pode chamar grant_admin', $$select grant_admin('00000000-0000-0000-0000-00000000000a')$$, 'permission denied');
select t_denied('cliente NÃO altera campos privilegiados do perfil', $$update profiles set accepted_terms_at = null where id = '00000000-0000-0000-0000-00000000000a'$$, 'permission denied');
select t_pass('cliente lê apenas o próprio perfil', (select count(*) from profiles) = 1);
update products set price_cents = 1;
update product_variants set stock = 9999;
select t_pass('cliente vê só produtos publicados', (select count(*) from products) = 1);
select t_pass('cliente NÃO lê cupons', (select count(*) from coupons) = 0);
select t_denied('cliente NÃO lê settings privados via tabela', $$select 1/(select count(*) from store_settings where key='shipping')$$, 'division by zero');
select t_denied('cliente NÃO chama apply_payment_event', $$select apply_payment_event(gen_random_uuid(),'x','paid','c')$$, 'permission denied');
select t_denied('cliente NÃO ajusta estoque', $$select admin_adjust_stock('a0000000-0000-0000-0000-000000000001', 100, 'teste')$$, 'forbidden');
select t_denied('cliente NÃO lê audit_log (0 linhas)', $$select 1/(select count(*) from audit_log)$$, 'division by zero');
select t_denied('cliente NÃO escreve em orders direto', $$insert into orders (user_id, idempotency_key, subtotal_cents, total_cents, shipping_address) values ('00000000-0000-0000-0000-00000000000a','k',1,1,'{}')$$, 'permission denied');
select as_pg();
select t_pass('RLS: update de cliente em produtos não altera nenhuma linha', not exists (select 1 from products where price_cents = 1));
select t_pass('RLS: update de cliente em estoque não altera nenhuma linha', not exists (select 1 from product_variants where stock = 9999));

-- cliente comum não vê custo (RLS devolve 0 linhas)
select as_user('00000000-0000-0000-0000-00000000000a');
select t_pass('RLS: product_costs invisível ao cliente', (select count(*) from product_costs) = 0);
select as_user('00000000-0000-0000-0000-0000000000ad');
select t_pass('RLS: admin vê custos', (select count(*) from product_costs) = 1);
select as_pg();

-- ===== Cotação, cupom e pedido =====
insert into cart_items (user_id, variant_id, quantity) values
 ('00000000-0000-0000-0000-00000000000a','a0000000-0000-0000-0000-000000000001', 1),
 ('00000000-0000-0000-0000-00000000000b','a0000000-0000-0000-0000-000000000001', 1);

select as_user('00000000-0000-0000-0000-00000000000a');
select t_pass('cotação: subtotal 10000 + frete 2000', (quote_cart(null)->>'total_cents')::int = 12000);
select t_pass('cupom 10% => desconto 1000', (quote_cart('off10')->>'discount_cents')::int = 1000);
select t_pass('cupom expirado rejeitado', (quote_cart('VELHO')->>'coupon_error') = 'expired');
select t_pass('cupom com mínimo não atingido rejeitado', (quote_cart('MIN500')->>'coupon_error') = 'min_subtotal');
select t_denied('cupom inválido bloqueia create_order', $$select create_order('d0000000-0000-0000-0000-00000000000a','VELHO','idem-0000001')$$, 'coupon_expired');
select t_denied('endereço de outro cliente é rejeitado (IDOR)', $$select create_order('d0000000-0000-0000-0000-00000000000b',null,'idem-0000002')$$, 'invalid_address');
select t_denied('cliente NÃO vê endereço alheio', $$select 1/(select count(*) from addresses where user_id = '00000000-0000-0000-0000-00000000000b')$$, 'division by zero');

create temp table t_ord(id uuid);
grant all on t_ord to public;
insert into t_ord select create_order('d0000000-0000-0000-0000-00000000000a','OFF10','idem-aaaaaaaa');
select t_pass('pedido criado com total no servidor = 10000-1000+2000', (select total_cents from orders where id = (select id from t_ord)) = 11000);
select t_pass('idempotência: mesma chave retorna o mesmo pedido', create_order('d0000000-0000-0000-0000-00000000000a','OFF10','idem-aaaaaaaa') = (select id from t_ord));
select as_pg();
select t_pass('estoque reservado (última unidade)', (select reserved from product_variants where id = 'a0000000-0000-0000-0000-000000000001') = 1);
select t_pass('cupom OFF10 consumido', (select uses from coupons where code = 'OFF10') = 1);

select as_user('00000000-0000-0000-0000-00000000000b');
select t_denied('segundo comprador NÃO leva a última unidade', $$select create_order('d0000000-0000-0000-0000-00000000000b',null,'idem-bbbbbbbb')$$, 'out_of_stock');
select t_pass('cliente B NÃO vê pedido de A', (select count(*) from orders) = 0);
select as_pg();

-- ===== Pagamentos =====
insert into payments (id, order_id, provider_payment_id, method, amount_cents)
  select 'e0000000-0000-0000-0000-000000000001', id, 'MP-1', 'pix', 11000 from t_ord;

select as_service();
select t_pass('pagamento aprovado aplicado', apply_payment_event('e0000000-0000-0000-0000-000000000001','ev-1','paid','corr-1') = 'applied');
select t_pass('notificação repetida não duplica', apply_payment_event('e0000000-0000-0000-0000-000000000001','ev-1','paid','corr-1') = 'duplicate');
select t_pass('transição inválida (paid→refused) ignorada', apply_payment_event('e0000000-0000-0000-0000-000000000001','ev-2','refused','corr-2') = 'ignored');
select as_pg();
select t_pass('pedido marcado como pago', (select payment_status from orders where id = (select id from t_ord)) = 'paid');
select t_pass('baixa definitiva: stock 0, reserved 0',
  (select stock = 0 and reserved = 0 from product_variants where id = 'a0000000-0000-0000-0000-000000000001'));
select t_pass('histórico financeiro gravado', (select count(*) from payment_events where payment_id = 'e0000000-0000-0000-0000-000000000001') = 2);
select t_pass('snapshot do item preservado no pedido', (select product_name from order_items where order_id = (select id from t_ord)) = 'Anel DEMO');

-- mudança posterior no catálogo não altera histórico
update products set name = 'Renomeado', price_cents = 99999 where id = '90000000-0000-0000-0000-000000000001';
select t_pass('histórico do pedido imune a edição do catálogo',
  (select product_name = 'Anel DEMO' and unit_price_cents = 10000 from order_items where order_id = (select id from t_ord)));

select as_service();
select t_pass('reembolso parcial', apply_payment_event('e0000000-0000-0000-0000-000000000001','ev-3','partially_refunded','corr-3','{}',null,3000) = 'applied');
select as_pg();
select t_pass('valor reembolsado registrado', (select refunded_cents from orders where id = (select id from t_ord)) = 3000);

-- ===== Expiração de reserva =====
select as_user('00000000-0000-0000-0000-0000000000ad');
select admin_adjust_stock('a0000000-0000-0000-0000-000000000002', 0, 'sem alteração');
select t_denied('ajuste de estoque exige motivo', $$select admin_adjust_stock('a0000000-0000-0000-0000-000000000002', 1, '')$$, 'reason_required');
select t_denied('ajuste não pode deixar estoque negativo', $$select admin_adjust_stock('a0000000-0000-0000-0000-000000000002', -999, 'teste')$$, 'stock_below_reserved');
select admin_adjust_stock('a0000000-0000-0000-0000-000000000002', 5, 'reposição');
select as_pg();
select t_pass('ajuste auditado em stock_movements', (select count(*) from stock_movements where reason = 'reposição') = 1);

insert into cart_items (user_id, variant_id, quantity) values ('00000000-0000-0000-0000-00000000000b','a0000000-0000-0000-0000-000000000002', 2);
delete from cart_items where variant_id = 'a0000000-0000-0000-0000-000000000001';
select as_user('00000000-0000-0000-0000-00000000000b');
create temp table t_ord2(id uuid); grant all on t_ord2 to public;
insert into t_ord2 select create_order('d0000000-0000-0000-0000-00000000000b',null,'idem-cccccccc');
select as_pg();
select t_pass('reserva criada', (select reserved from product_variants where id = 'a0000000-0000-0000-0000-000000000002') = 2);
update orders set reservation_expires_at = now() - interval '1 minute' where id = (select id from t_ord2);
select t_pass('job de expiração libera reservas', release_expired_reservations() = 1);
select t_pass('reserva devolvida ao estoque', (select reserved from product_variants where id = 'a0000000-0000-0000-0000-000000000002') = 0);
select t_pass('pedido marcado como expirado', (select payment_status from orders where id = (select id from t_ord2)) = 'expired');

-- ===== Fulfillment =====
select as_user('00000000-0000-0000-0000-0000000000ad');
select t_denied('não envia pedido não pago', format($$select admin_update_fulfillment(%L,'shipped','BR123',null)$$, (select id from t_ord2)), 'order_not_paid');
select admin_update_fulfillment((select id from t_ord), 'shipped', 'BR123456789', 'ok');
select as_pg();
select t_pass('rastreamento gravado', (select tracking_code from orders where id = (select id from t_ord)) = 'BR123456789');

-- ===== Imutabilidade de logs =====
select t_denied('audit_log append-only (superusuário também)', $$delete from audit_log$$, 'append-only');
select as_user('00000000-0000-0000-0000-0000000000ad');
select t_denied('admin NÃO apaga audit_log pela API', $$delete from audit_log$$, 'permission denied');
select as_pg();
select t_pass('auditoria registrou concessão de admin', (select count(*) from audit_log where object_type = 'user_roles' and action = 'INSERT') >= 3);

-- ===== Constraints =====
select t_denied('preço promocional >= preço é recusado', $$insert into products (slug,name,price_cents,sale_price_cents) values ('x','Xx',100,100)$$, 'check');
select t_denied('estoque negativo é recusado', $$update product_variants set stock = -1$$, 'check');
select t_denied('cupom percentual > 100 recusado', $$insert into coupons (code,kind,value) values ('ZZZ','percent',150)$$, 'check');
