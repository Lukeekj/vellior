-- VELLIOR — Row Level Security. Princípio: bloqueado por padrão; cada acesso é liberado explicitamente.

alter table public.user_roles enable row level security;
alter table public.profiles enable row level security;
alter table public.addresses enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_costs enable row level security;
alter table public.product_variants enable row level security;
alter table public.product_images enable row level security;
alter table public.coupons enable row level security;
alter table public.cart_items enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.payment_events enable row level security;
alter table public.stock_movements enable row level security;
alter table public.audit_log enable row level security;
alter table public.store_settings enable row level security;
alter table public.payment_methods_config enable row level security;

-- user_roles: ninguém escreve pela API. Somente leitura do próprio papel / admin lê todos.
create policy roles_select_own on public.user_roles for select using (user_id = auth.uid());
create policy roles_select_admin on public.user_roles for select using (public.is_admin());

-- profiles
create policy profiles_select_own on public.profiles for select using (id = auth.uid());
create policy profiles_select_staff on public.profiles for select using (public.is_admin());
create policy profiles_update_own on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

-- addresses
create policy addr_select on public.addresses for select using (user_id = auth.uid());
create policy addr_insert on public.addresses for insert with check (user_id = auth.uid());
create policy addr_update on public.addresses for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy addr_delete on public.addresses for delete using (user_id = auth.uid());
create policy addr_staff_select on public.addresses for select using (public.is_admin());

-- categories
create policy cat_public_read on public.categories for select using (published or public.is_staff());
create policy cat_admin_ins on public.categories for insert with check (public.is_admin());
create policy cat_admin_upd on public.categories for update using (public.is_admin()) with check (public.is_admin());
create policy cat_admin_del on public.categories for delete using (public.is_admin());

-- products
create policy prod_public_read on public.products for select using ((published and not archived) or public.is_staff());
create policy prod_admin_ins on public.products for insert with check (public.is_admin());
create policy prod_admin_upd on public.products for update using (public.is_admin()) with check (public.is_admin());
create policy prod_admin_del on public.products for delete using (public.is_admin());

-- custo: só admin
create policy cost_admin_all on public.product_costs for all using (public.is_admin()) with check (public.is_admin());

-- variants
create policy var_public_read on public.product_variants for select using (
  public.is_staff() or (active and exists (
    select 1 from public.products p where p.id = product_id and p.published and not p.archived))
);
create policy var_admin_ins on public.product_variants for insert with check (public.is_admin());
create policy var_admin_upd on public.product_variants for update using (public.is_admin()) with check (public.is_admin());
create policy var_admin_del on public.product_variants for delete using (public.is_admin());

-- images
create policy img_public_read on public.product_images for select using (
  public.is_staff() or exists (select 1 from public.products p where p.id = product_id and p.published and not p.archived)
);
create policy img_admin_ins on public.product_images for insert with check (public.is_admin());
create policy img_admin_upd on public.product_images for update using (public.is_admin()) with check (public.is_admin());
create policy img_admin_del on public.product_images for delete using (public.is_admin());

-- cupons: clientes NÃO leem a tabela (evita listar códigos). Validação via RPC.
create policy coupons_admin_all on public.coupons for all using (public.is_admin()) with check (public.is_admin());

-- carrinho
create policy cart_select on public.cart_items for select using (user_id = auth.uid());
create policy cart_insert on public.cart_items for insert with check (user_id = auth.uid());
create policy cart_update on public.cart_items for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy cart_delete on public.cart_items for delete using (user_id = auth.uid());

-- pedidos: leitura própria / staff. Escrita SOMENTE por funções security definer.
create policy orders_select_own on public.orders for select using (user_id = auth.uid());
create policy orders_select_staff on public.orders for select using (public.is_staff());
create policy oitems_select_own on public.order_items for select using (
  exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
create policy oitems_select_staff on public.order_items for select using (public.is_staff());

-- pagamentos: leitura própria; eventos/estoque/auditoria: só staff leitura. Sem escrita pela API.
create policy pay_select_own on public.payments for select using (
  exists (select 1 from public.orders o where o.id = order_id and o.user_id = auth.uid()));
create policy pay_select_staff on public.payments for select using (public.is_staff());
create policy payev_select_admin on public.payment_events for select using (public.is_admin());
create policy stockmov_select_staff on public.stock_movements for select using (public.is_staff());
create policy audit_select_admin on public.audit_log for select using (public.is_admin());

-- configurações
create policy settings_public_read on public.store_settings for select using (is_public or public.is_admin());
create policy settings_admin_ins on public.store_settings for insert with check (public.is_admin());
create policy settings_admin_upd on public.store_settings for update using (public.is_admin()) with check (public.is_admin());
create policy pmc_public_read on public.payment_methods_config for select using (true);
create policy pmc_admin_upd on public.payment_methods_config for update using (public.is_admin()) with check (public.is_admin());

-- Privilégios de tabela: remove tudo de anon e libera o mínimo.
revoke all on all tables in schema public from anon, authenticated;
revoke all on all sequences in schema public from anon, authenticated;
revoke all on all functions in schema public from public, anon, authenticated;

grant select on public.categories, public.products, public.product_variants, public.product_images,
  public.store_settings, public.payment_methods_config to anon, authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.addresses, public.cart_items to authenticated;
grant select on public.user_roles, public.orders, public.order_items, public.payments,
  public.payment_events, public.stock_movements, public.audit_log to authenticated;
grant select, insert, update, delete on public.coupons, public.product_costs to authenticated;
grant insert, update, delete on public.categories, public.products, public.product_variants,
  public.product_images, public.store_settings to authenticated;
grant update on public.payment_methods_config to authenticated;

-- Impede que o cliente altere campos privilegiados do perfil (mass assignment)
revoke update on public.profiles from authenticated;
grant update (full_name, phone) on public.profiles to authenticated;

grant execute on function public.has_role(uuid, public.app_role), public.is_staff(), public.is_admin() to anon, authenticated;

-- Storage: bucket de imagens de produtos (leitura pública; escrita só admin; 5 MB; só imagens)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-images', 'product-images', true, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create policy "product images admin write" on storage.objects for insert to authenticated
  with check (bucket_id = 'product-images' and public.is_admin());
create policy "product images admin update" on storage.objects for update to authenticated
  using (bucket_id = 'product-images' and public.is_admin());
create policy "product images admin delete" on storage.objects for delete to authenticated
  using (bucket_id = 'product-images' and public.is_admin());
