-- VELLIOR — operações críticas no banco (atômicas). Preços, descontos, frete e estoque são SEMPRE calculados aqui.

-- ============ AUDITORIA GENÉRICA ============
create or replace function public.audit_trigger() returns trigger
language plpgsql security definer set search_path = public as $$
declare _id text;
begin
  _id := coalesce((to_jsonb(coalesce(new, old))->>'id'), (to_jsonb(coalesce(new, old))->>'key'),
                  (to_jsonb(coalesce(new, old))->>'method'), (to_jsonb(coalesce(new, old))->>'product_id'),
                  (to_jsonb(coalesce(new, old))->>'user_id'));
  insert into public.audit_log (actor, action, object_type, object_id, detail)
  values (auth.uid(), tg_op, tg_table_name, _id,
          jsonb_build_object('new', case when tg_op <> 'DELETE' then to_jsonb(new) end,
                             'old', case when tg_op <> 'INSERT' then to_jsonb(old) end));
  return coalesce(new, old);
end $$;

create trigger a_products after insert or update or delete on public.products for each row execute function public.audit_trigger();
create trigger a_variants after insert or update or delete on public.product_variants for each row execute function public.audit_trigger();
create trigger a_costs after insert or update or delete on public.product_costs for each row execute function public.audit_trigger();
create trigger a_coupons after insert or update or delete on public.coupons for each row execute function public.audit_trigger();
create trigger a_roles after insert or update or delete on public.user_roles for each row execute function public.audit_trigger();
create trigger a_settings after insert or update or delete on public.store_settings for each row execute function public.audit_trigger();
create trigger a_pmc after update on public.payment_methods_config for each row execute function public.audit_trigger();
create trigger a_categories after insert or update or delete on public.categories for each row execute function public.audit_trigger();

-- Logs, eventos e movimentos são append-only: ninguém (nem admin pela API) altera ou apaga.
create or replace function public.forbid_mutation() returns trigger language plpgsql as $$
begin raise exception 'tabela somente de inserção (append-only)'; end $$;
create trigger audit_immutable before update or delete on public.audit_log for each row execute function public.forbid_mutation();
create trigger payev_immutable before update or delete on public.payment_events for each row execute function public.forbid_mutation();
create trigger stockmov_immutable before update or delete on public.stock_movements for each row execute function public.forbid_mutation();

-- ============ COTAÇÃO DO CARRINHO (sem efeitos colaterais) ============
create or replace function public._compute_quote(p_uid uuid, p_coupon text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  _lines jsonb := '[]'::jsonb;
  _subtotal int := 0;
  _discount int := 0;
  _eligible int := 0;
  _shipping int := 0;
  _ship jsonb;
  _c public.coupons;
  _cerr text := null;
  r record;
  _unit int;
begin
  for r in
    select ci.variant_id, ci.quantity, v.sku, v.label, v.price_cents as v_price, v.stock, v.reserved, v.active,
           p.id as product_id, p.name, p.price_cents as p_price, p.sale_price_cents, p.category_id, p.published, p.archived
    from public.cart_items ci
    join public.product_variants v on v.id = ci.variant_id
    join public.products p on p.id = v.product_id
    where ci.user_id = p_uid
    order by v.id
  loop
    _unit := case when r.v_price is null and r.sale_price_cents is not null then r.sale_price_cents
                  else coalesce(r.v_price, r.p_price) end;
    _subtotal := _subtotal + _unit * r.quantity;
    _lines := _lines || jsonb_build_object(
      'variant_id', r.variant_id, 'product_id', r.product_id, 'product_name', r.name, 'variant_label', r.label,
      'sku', r.sku, 'unit_cents', _unit, 'quantity', r.quantity,
      'available', (r.active and r.published and not r.archived and (r.stock - r.reserved) >= r.quantity));
  end loop;

  if p_coupon is not null and length(trim(p_coupon)) > 0 then
    select * into _c from public.coupons where code = upper(trim(p_coupon));
    if not found or not _c.active then _cerr := 'invalid';
    elsif _c.starts_at is not null and _c.starts_at > now() then _cerr := 'invalid';
    elsif _c.expires_at is not null and _c.expires_at < now() then _cerr := 'expired';
    elsif _c.max_uses is not null and _c.uses >= _c.max_uses then _cerr := 'exhausted';
    elsif _subtotal < _c.min_subtotal_cents then _cerr := 'min_subtotal';
    else
      select coalesce(sum((l->>'unit_cents')::int * (l->>'quantity')::int), 0) into _eligible
      from jsonb_array_elements(_lines) l
      join public.products p on p.id = (l->>'product_id')::uuid
      where (_c.category_id is null or p.category_id = _c.category_id)
        and (_c.product_id is null or p.id = _c.product_id);
      if _eligible = 0 then _cerr := 'not_applicable';
      else
        _discount := case when _c.kind = 'percent' then (_eligible * _c.value) / 100 else _c.value end;
        _discount := greatest(0, least(_discount, _eligible));
      end if;
    end if;
  end if;

  select value into _ship from public.store_settings where key = 'shipping';
  if _ship is not null and _subtotal > 0 then
    _shipping := coalesce((_ship->>'flat_cents')::int, 0);
    if (_ship->>'free_over_cents') is not null and _subtotal - _discount >= (_ship->>'free_over_cents')::int then
      _shipping := 0;
    end if;
  end if;

  return jsonb_build_object(
    'lines', _lines, 'subtotal_cents', _subtotal, 'discount_cents', _discount, 'shipping_cents', _shipping,
    'total_cents', _subtotal - _discount + _shipping,
    'coupon_code', case when _cerr is null and _discount > 0 then upper(trim(p_coupon)) end,
    'coupon_error', _cerr);
end $$;

create or replace function public.quote_cart(p_coupon text default null)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  return public._compute_quote(auth.uid(), p_coupon);
end $$;

-- ============ CRIAÇÃO DE PEDIDO (atômica, idempotente) ============
create or replace function public.create_order(p_address_id uuid, p_coupon text, p_idempotency_key text)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  _uid uuid := auth.uid();
  _existing uuid;
  _addr public.addresses;
  _q jsonb;
  _order uuid;
  _l jsonb;
  _v public.product_variants;
  _qty int;
  _c public.coupons;
begin
  if _uid is null then raise exception 'not_authenticated'; end if;
  if p_idempotency_key is null or length(p_idempotency_key) not between 8 and 100 then raise exception 'invalid_idempotency_key'; end if;

  -- idempotência
  select id into _existing from public.orders where user_id = _uid and idempotency_key = p_idempotency_key;
  if found then return _existing; end if;

  -- limite de abuso: no máximo 10 pedidos abertos por hora por usuário
  if (select count(*) from public.orders where user_id = _uid and created_at > now() - interval '1 hour') >= 10 then
    raise exception 'rate_limited';
  end if;

  select * into _addr from public.addresses where id = p_address_id and user_id = _uid;
  if not found then raise exception 'invalid_address'; end if;

  -- trava as variantes do carrinho em ordem determinística (evita deadlock e venda da última unidade em duplicidade)
  perform 1 from public.product_variants v
    where v.id in (select variant_id from public.cart_items where user_id = _uid)
    order by v.id for update;

  _q := public._compute_quote(_uid, p_coupon);
  if jsonb_array_length(_q->'lines') = 0 then raise exception 'empty_cart'; end if;
  if p_coupon is not null and length(trim(p_coupon)) > 0 and (_q->>'coupon_error') is not null then
    raise exception 'coupon_%', (_q->>'coupon_error');
  end if;
  if exists (select 1 from jsonb_array_elements(_q->'lines') l where not (l->>'available')::boolean) then
    raise exception 'out_of_stock';
  end if;
  if (_q->>'total_cents')::int <= 0 then raise exception 'invalid_total'; end if;

  if (_q->>'coupon_code') is not null then
    select * into _c from public.coupons where code = _q->>'coupon_code' for update;
    if _c.max_uses is not null and _c.uses >= _c.max_uses then raise exception 'coupon_exhausted'; end if;
    update public.coupons set uses = uses + 1 where id = _c.id;
  end if;

  insert into public.orders (user_id, idempotency_key, subtotal_cents, discount_cents, shipping_cents, total_cents,
                             coupon_code, shipping_address, reservation_expires_at)
  values (_uid, p_idempotency_key, (_q->>'subtotal_cents')::int, (_q->>'discount_cents')::int,
          (_q->>'shipping_cents')::int, (_q->>'total_cents')::int, _q->>'coupon_code',
          to_jsonb(_addr) - 'user_id' - 'created_at', now() + interval '30 minutes')
  returning id into _order;

  for _l in select * from jsonb_array_elements(_q->'lines') loop
    _qty := (_l->>'quantity')::int;
    insert into public.order_items (order_id, variant_id, product_name, variant_label, sku, unit_price_cents, quantity)
    values (_order, (_l->>'variant_id')::uuid, _l->>'product_name', _l->>'variant_label', _l->>'sku',
            (_l->>'unit_cents')::int, _qty);
    update public.product_variants set reserved = reserved + _qty where id = (_l->>'variant_id')::uuid;
    insert into public.stock_movements (variant_id, delta, kind, order_id, actor)
    values ((_l->>'variant_id')::uuid, -_qty, 'reserve', _order, _uid);
  end loop;

  return _order;
end $$;

-- ============ LIBERAÇÃO DE RESERVA ============
create or replace function public._release_order(p_order uuid, p_actor uuid default null)
returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in select variant_id, quantity from public.order_items where order_id = p_order and variant_id is not null loop
    update public.product_variants set reserved = greatest(0, reserved - r.quantity) where id = r.variant_id;
    insert into public.stock_movements (variant_id, delta, kind, order_id, actor)
    values (r.variant_id, r.quantity, 'release', p_order, p_actor);
  end loop;
  update public.coupons set uses = greatest(0, uses - 1)
    where code = (select coupon_code from public.orders where id = p_order);
end $$;

create or replace function public.release_expired_reservations()
returns int language plpgsql security definer set search_path = public as $$
declare o record; n int := 0;
begin
  for o in select id from public.orders
           where payment_status = 'awaiting_payment' and reservation_expires_at < now()
           for update skip locked loop
    update public.orders set payment_status = 'expired', fulfillment_status = 'cancelled' where id = o.id;
    update public.payments set status = 'expired' where order_id = o.id and status in ('awaiting_payment','processing');
    perform public._release_order(o.id);
    insert into public.payment_events (order_id, from_status, to_status, correlation_id, detail)
      values (o.id, 'awaiting_payment', 'expired', 'reservation-expiry', '{"reason":"reservation_expired"}');
    n := n + 1;
  end loop;
  return n;
end $$;

-- ============ TRANSIÇÕES FINANCEIRAS (idempotentes; só service_role) ============
create or replace function public.apply_payment_event(
  p_payment_id uuid, p_event_id text, p_new_status public.payment_status,
  p_correlation text, p_detail jsonb default '{}'::jsonb,
  p_provider_payment_id text default null, p_refunded_cents int default null)
returns text language plpgsql security definer set search_path = public as $$
declare
  _p public.payments;
  _o public.orders;
  _ok boolean;
  r record;
  _ref int;
begin
  select * into _p from public.payments where id = p_payment_id for update;
  if not found then raise exception 'payment_not_found'; end if;
  select * into _o from public.orders where id = _p.order_id for update;

  if p_event_id is not null and exists (select 1 from public.payment_events where provider_event_id = p_event_id) then
    return 'duplicate';
  end if;
  if _p.status = p_new_status and p_new_status not in ('partially_refunded') then return 'noop'; end if;

  _ok := case _p.status
    when 'awaiting_payment' then p_new_status in ('processing','paid','refused','expired','cancelled')
    when 'processing' then p_new_status in ('paid','refused','expired','cancelled')
    when 'paid' then p_new_status in ('refunded','partially_refunded')
    when 'partially_refunded' then p_new_status in ('refunded','partially_refunded')
    else false end;
  if not _ok then
    insert into public.payment_events (payment_id, order_id, provider_event_id, from_status, to_status, correlation_id, detail)
    values (_p.id, _p.order_id, p_event_id, _p.status, p_new_status, p_correlation,
            coalesce(p_detail, '{}'::jsonb) || '{"ignored":"invalid_transition"}');
    return 'ignored';
  end if;

  if p_new_status = 'paid' then
    if _o.payment_status in ('awaiting_payment','processing') then
      -- converte reserva em baixa definitiva
      for r in select variant_id, quantity from public.order_items where order_id = _o.id and variant_id is not null loop
        update public.product_variants set stock = greatest(0, stock - r.quantity), reserved = greatest(0, reserved - r.quantity)
          where id = r.variant_id;
        insert into public.stock_movements (variant_id, delta, kind, order_id) values (r.variant_id, -r.quantity, 'sale', _o.id);
      end loop;
    else
      -- pagamento aprovado depois de expirar/cancelar: sinaliza para atendimento (possível reembolso)
      update public.orders set admin_notes = coalesce(admin_notes || E'\n', '') ||
        'ATENÇÃO: pagamento aprovado após expiração/cancelamento. Verificar estoque ou reembolsar.' where id = _o.id;
    end if;
    update public.orders set payment_status = 'paid',
      fulfillment_status = case when fulfillment_status = 'cancelled' then fulfillment_status else 'preparing' end
      where id = _o.id;
    delete from public.cart_items where user_id = _o.user_id;
  elsif p_new_status in ('refused','expired','cancelled') then
    if _o.payment_status in ('awaiting_payment','processing') then
      perform public._release_order(_o.id);
    end if;
    update public.orders set payment_status = p_new_status,
      fulfillment_status = 'cancelled' where id = _o.id and payment_status in ('awaiting_payment','processing');
  elsif p_new_status = 'processing' then
    update public.orders set payment_status = 'processing' where id = _o.id and payment_status = 'awaiting_payment';
  elsif p_new_status in ('refunded','partially_refunded') then
    _ref := least(_o.total_cents, coalesce(p_refunded_cents, case when p_new_status = 'refunded' then _o.total_cents else _o.refunded_cents end));
    update public.orders set payment_status = p_new_status, refunded_cents = _ref where id = _o.id;
  end if;

  update public.payments set status = p_new_status,
    provider_payment_id = coalesce(p_provider_payment_id, provider_payment_id) where id = _p.id;

  insert into public.payment_events (payment_id, order_id, provider_event_id, from_status, to_status, correlation_id, detail)
  values (_p.id, _p.order_id, p_event_id, _p.status, p_new_status, p_correlation, p_detail);
  return 'applied';
end $$;

-- ============ OPERAÇÕES ADMINISTRATIVAS ============
create or replace function public.admin_update_fulfillment(p_order uuid, p_status public.fulfillment_status, p_tracking text, p_notes text)
returns void language plpgsql security definer set search_path = public as $$
declare _o public.orders;
begin
  if not public.is_staff() then raise exception 'forbidden'; end if;
  select * into _o from public.orders where id = p_order for update;
  if not found then raise exception 'order_not_found'; end if;
  if p_status in ('shipped','delivered') and _o.payment_status not in ('paid','partially_refunded') then
    raise exception 'order_not_paid';
  end if;
  if p_tracking is not null and length(p_tracking) > 60 then raise exception 'invalid_tracking'; end if;
  if p_notes is not null and length(p_notes) > 2000 then raise exception 'invalid_notes'; end if;
  update public.orders set fulfillment_status = p_status,
    tracking_code = coalesce(nullif(trim(p_tracking), ''), tracking_code),
    admin_notes = coalesce(p_notes, admin_notes) where id = p_order;
  insert into public.audit_log (actor, action, object_type, object_id, detail)
  values (auth.uid(), 'fulfillment_update', 'orders', p_order::text,
          jsonb_build_object('from', _o.fulfillment_status, 'to', p_status, 'tracking', p_tracking));
end $$;

create or replace function public.admin_adjust_stock(p_variant uuid, p_delta int, p_reason text)
returns void language plpgsql security definer set search_path = public as $$
declare _v public.product_variants;
begin
  if not public.is_admin() then raise exception 'forbidden'; end if;
  if p_reason is null or length(trim(p_reason)) < 3 then raise exception 'reason_required'; end if;
  select * into _v from public.product_variants where id = p_variant for update;
  if not found then raise exception 'variant_not_found'; end if;
  if _v.stock + p_delta < _v.reserved then raise exception 'stock_below_reserved'; end if;
  update public.product_variants set stock = stock + p_delta where id = p_variant;
  insert into public.stock_movements (variant_id, delta, kind, actor, reason)
  values (p_variant, p_delta, case when p_delta >= 0 then 'restock' else 'admin_adjust' end, auth.uid(), p_reason);
end $$;

create or replace function public.admin_dashboard(p_from timestamptz, p_to timestamptz)
returns jsonb language plpgsql security definer set search_path = public as $$
declare _res jsonb;
begin
  if not public.is_staff() then raise exception 'forbidden'; end if;
  select jsonb_build_object(
    'paid_orders', count(*) filter (where payment_status in ('paid','partially_refunded','refunded')),
    'gross_cents', coalesce(sum(subtotal_cents + shipping_cents) filter (where payment_status in ('paid','partially_refunded','refunded')), 0),
    'discount_cents', coalesce(sum(discount_cents) filter (where payment_status in ('paid','partially_refunded','refunded')), 0),
    'refunded_cents', coalesce(sum(refunded_cents), 0),
    'net_estimated_cents', coalesce(sum(total_cents - refunded_cents) filter (where payment_status in ('paid','partially_refunded','refunded')), 0),
    'awaiting_payment', count(*) filter (where payment_status in ('awaiting_payment','processing'))
  ) into _res
  from public.orders where created_at >= p_from and created_at < p_to;

  _res := _res || jsonb_build_object(
    'low_stock', (select count(*) from public.product_variants where active and (stock - reserved) <= low_stock_threshold),
    'top_products', coalesce((
      select jsonb_agg(t) from (
        select oi.product_name, sum(oi.quantity)::int as qty
        from public.order_items oi join public.orders o on o.id = oi.order_id
        where o.payment_status in ('paid','partially_refunded') and o.created_at >= p_from and o.created_at < p_to
        group by oi.product_name order by qty desc limit 5) t), '[]'::jsonb),
    'daily', coalesce((
      select jsonb_agg(d order by d.day) from (
        select date_trunc('day', created_at at time zone 'America/Sao_Paulo')::date as day,
               sum(total_cents)::int as total_cents
        from public.orders
        where payment_status in ('paid','partially_refunded') and created_at >= p_from and created_at < p_to
        group by 1) d), '[]'::jsonb));
  return _res;
end $$;

-- Somente service_role / SQL Editor: concede papel de admin (primeiro admin: ver docs/ADMIN.md)
create or replace function public.grant_admin(p_user uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into public.user_roles (user_id, role) values (p_user, 'admin') on conflict do nothing;
end $$;

-- ============ PERMISSÕES DE EXECUÇÃO ============
revoke all on function public._compute_quote(uuid, text), public._release_order(uuid, uuid),
  public.release_expired_reservations(), public.grant_admin(uuid),
  public.apply_payment_event(uuid, text, public.payment_status, text, jsonb, text, int) from public, anon, authenticated;

grant execute on function public.quote_cart(text), public.create_order(uuid, text, text),
  public.admin_update_fulfillment(uuid, public.fulfillment_status, text, text),
  public.admin_adjust_stock(uuid, int, text), public.admin_dashboard(timestamptz, timestamptz) to authenticated;

grant execute on function public.apply_payment_event(uuid, text, public.payment_status, text, jsonb, text, int),
  public.release_expired_reservations(), public.grant_admin(uuid) to service_role;
