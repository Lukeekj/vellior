-- VELLIOR — esquema base. Valores monetários em centavos (integer) para evitar erros de ponto flutuante.

create extension if not exists pgcrypto;

-- ============ PAPÉIS ============
create type public.app_role as enum ('customer', 'admin', 'operator');

create table public.user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role public.app_role not null,
  granted_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  primary key (user_id, role)
);

create or replace function public.has_role(_user uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user and role = _role);
$$;

create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(auth.uid(), 'admin') or public.has_role(auth.uid(), 'operator');
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(auth.uid(), 'admin');
$$;

-- ============ PERFIS ============
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null check (char_length(full_name) between 2 and 120),
  phone text check (phone is null or char_length(phone) <= 30),
  accepted_terms_at timestamptz,
  terms_version text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Cria perfil e papel 'customer' automaticamente. NUNCA cria admin.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name, accepted_terms_at, terms_version)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data->>'full_name'), ''), nullif(trim(new.raw_user_meta_data->>'name'), ''), 'Cliente'),
    case when (new.raw_user_meta_data->>'accepted_terms') = 'true' then now() end,
    case when (new.raw_user_meta_data->>'accepted_terms') = 'true' then 'v1' end
  );
  insert into public.user_roles (user_id, role) values (new.id, 'customer');
  return new;
end $$;

create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

create table public.addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  recipient text not null check (char_length(recipient) between 2 and 120),
  zip text not null check (zip ~ '^[0-9]{8}$'),
  street text not null check (char_length(street) <= 160),
  number text not null check (char_length(number) <= 20),
  complement text check (complement is null or char_length(complement) <= 80),
  district text not null check (char_length(district) <= 80),
  city text not null check (char_length(city) <= 80),
  state text not null check (state ~ '^[A-Z]{2}$'),
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);
create index on public.addresses (user_id);

-- ============ CATÁLOGO ============
create table public.categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  name text not null,
  description text,
  image_url text,
  position int not null default 0,
  published boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  name text not null check (char_length(name) between 2 and 160),
  description text,
  category_id uuid references public.categories(id),
  price_cents int not null check (price_cents >= 0),
  sale_price_cents int check (sale_price_cents is null or (sale_price_cents >= 0 and sale_price_cents < price_cents)),
  material text,
  dimensions text,
  weight_grams int check (weight_grams is null or weight_grams > 0),
  featured boolean not null default false,
  published boolean not null default false,
  archived boolean not null default false,
  is_demo boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index on public.products (category_id);
create index on public.products (published, archived);

-- Dados sensíveis (custo) em tabela separada: somente staff com política própria.
create table public.product_costs (
  product_id uuid primary key references public.products(id) on delete cascade,
  cost_cents int not null check (cost_cents >= 0)
);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  sku text not null unique,
  label text not null,          -- ex.: "Dourado / 18"
  color text,
  size text,
  price_cents int check (price_cents is null or price_cents >= 0), -- null = usa preço do produto
  stock int not null default 0 check (stock >= 0),
  reserved int not null default 0 check (reserved >= 0),
  low_stock_threshold int not null default 3 check (low_stock_threshold >= 0),
  active boolean not null default true,
  check (reserved <= stock)
);
create index on public.product_variants (product_id);

create table public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  path text not null,
  alt text,
  position int not null default 0
);
create index on public.product_images (product_id);

-- ============ CUPONS ============
create table public.coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique check (code = upper(code) and char_length(code) between 3 and 40),
  kind text not null check (kind in ('percent', 'fixed')),
  value int not null check (value > 0),
  check (kind <> 'percent' or value <= 100),
  min_subtotal_cents int not null default 0 check (min_subtotal_cents >= 0),
  starts_at timestamptz,
  expires_at timestamptz,
  max_uses int check (max_uses is null or max_uses > 0),
  uses int not null default 0 check (uses >= 0),
  category_id uuid references public.categories(id),
  product_id uuid references public.products(id),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

-- ============ CARRINHO ============
create table public.cart_items (
  user_id uuid not null references auth.users(id) on delete cascade,
  variant_id uuid not null references public.product_variants(id) on delete cascade,
  quantity int not null check (quantity between 1 and 20),
  updated_at timestamptz not null default now(),
  primary key (user_id, variant_id)
);

-- ============ PEDIDOS ============
create type public.payment_status as enum
  ('awaiting_payment','processing','paid','refused','expired','cancelled','refunded','partially_refunded');
create type public.fulfillment_status as enum
  ('pending','preparing','shipped','delivered','cancelled');

create sequence public.order_number_seq start 1001;

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  number bigint not null unique default nextval('public.order_number_seq'),
  user_id uuid not null references auth.users(id),
  idempotency_key text not null,
  payment_status public.payment_status not null default 'awaiting_payment',
  fulfillment_status public.fulfillment_status not null default 'pending',
  subtotal_cents int not null check (subtotal_cents >= 0),
  discount_cents int not null default 0 check (discount_cents >= 0),
  shipping_cents int not null default 0 check (shipping_cents >= 0),
  total_cents int not null check (total_cents >= 0),
  refunded_cents int not null default 0 check (refunded_cents >= 0),
  coupon_code text,
  shipping_address jsonb not null,     -- fotografia histórica do endereço
  tracking_code text,
  admin_notes text,
  reservation_expires_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, idempotency_key),
  check (total_cents = subtotal_cents - discount_cents + shipping_cents),
  check (refunded_cents <= total_cents)
);
create index on public.orders (user_id);
create index on public.orders (payment_status);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  variant_id uuid references public.product_variants(id) on delete set null,
  product_name text not null,   -- fotografia histórica
  variant_label text not null,
  sku text not null,
  unit_price_cents int not null check (unit_price_cents >= 0),
  quantity int not null check (quantity > 0)
);
create index on public.order_items (order_id);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id),
  provider text not null default 'mercadopago',
  provider_payment_id text,
  method text not null check (method in ('pix','credit_card')),
  status public.payment_status not null default 'awaiting_payment',
  amount_cents int not null check (amount_cents > 0),
  pix_qr_code text,
  pix_expires_at timestamptz,
  environment text not null default 'sandbox' check (environment in ('sandbox','production')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, provider_payment_id)
);
create index on public.payments (order_id);

-- Histórico imutável de transições financeiras + deduplicação de webhooks.
create table public.payment_events (
  id bigint generated always as identity primary key,
  payment_id uuid references public.payments(id),
  order_id uuid references public.orders(id),
  provider_event_id text unique,       -- idempotência: notificações repetidas não duplicam
  from_status public.payment_status,
  to_status public.payment_status,
  correlation_id text,
  detail jsonb,
  created_at timestamptz not null default now()
);

create table public.stock_movements (
  id bigint generated always as identity primary key,
  variant_id uuid not null references public.product_variants(id),
  delta int not null,
  kind text not null check (kind in ('reserve','release','sale','admin_adjust','restock')),
  order_id uuid references public.orders(id),
  actor uuid references auth.users(id),
  reason text,
  created_at timestamptz not null default now()
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor uuid,
  action text not null,
  object_type text,
  object_id text,
  detail jsonb,
  created_at timestamptz not null default now()
);

-- Configurações: públicas (leitura aberta) e privadas separadas. Segredos NUNCA aqui.
create table public.store_settings (
  key text primary key,
  value jsonb not null,
  is_public boolean not null default false,
  updated_at timestamptz not null default now()
);

create table public.payment_methods_config (
  method text primary key check (method in ('pix','credit_card')),
  enabled boolean not null default false,
  max_installments int not null default 1 check (max_installments between 1 and 12)
);
insert into public.payment_methods_config (method, enabled) values ('pix', false), ('credit_card', false);

-- updated_at
create or replace function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
create trigger t_products_upd before update on public.products for each row execute function public.touch_updated_at();
create trigger t_profiles_upd before update on public.profiles for each row execute function public.touch_updated_at();
create trigger t_orders_upd before update on public.orders for each row execute function public.touch_updated_at();
create trigger t_payments_upd before update on public.payments for each row execute function public.touch_updated_at();
