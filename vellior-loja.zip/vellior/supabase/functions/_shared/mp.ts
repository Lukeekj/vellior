// Lógica pura do Mercado Pago (sem APIs específicas do Deno => testável com vitest).

export type PaymentStatus =
  | "awaiting_payment" | "processing" | "paid" | "refused" | "expired" | "cancelled" | "refunded" | "partially_refunded";

/** Converte o status do Mercado Pago para o status interno. */
export function mapMpStatus(mpStatus: string, refundedAmount = 0, totalAmount = 0): PaymentStatus {
  switch (mpStatus) {
    case "approved":
    case "authorized":
      return "paid";
    case "pending":
      return "awaiting_payment";
    case "in_process":
    case "in_mediation":
      return "processing";
    case "rejected":
      return "refused";
    case "cancelled":
      return "cancelled";
    case "refunded":
    case "charged_back":
      return "refunded";
    default:
      // partially refunded chega como "approved" com transaction_amount_refunded > 0
      return "processing";
  }
}

export function mapApprovedWithRefund(mpStatus: string, refunded: number, total: number): PaymentStatus {
  if (mpStatus === "approved" && refunded > 0) return refunded >= total ? "refunded" : "partially_refunded";
  return mapMpStatus(mpStatus);
}

export function toCents(amount: number): number {
  return Math.round(amount * 100);
}

export function fromCents(cents: number): number {
  return Math.round(cents) / 100;
}

function hex(buf: ArrayBuffer): string {
  return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function timingSafeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/**
 * Valida o cabeçalho x-signature do Mercado Pago.
 * manifest = "id:<data.id minúsculo>;request-id:<x-request-id>;ts:<ts>;"
 * Tolerância de relógio: 10 min (anti-replay).
 */
export async function verifyMpSignature(opts: {
  secret: string; signatureHeader: string | null; requestId: string | null; dataId: string | null; nowMs?: number;
}): Promise<boolean> {
  const { secret, signatureHeader, requestId, dataId } = opts;
  if (!secret || !signatureHeader || !requestId || !dataId) return false;
  const parts = Object.fromEntries(
    signatureHeader.split(",").map((p) => {
      const i = p.indexOf("=");
      return [p.slice(0, i).trim(), p.slice(i + 1).trim()];
    }),
  );
  const ts = parts["ts"], v1 = parts["v1"];
  if (!ts || !v1) return false;
  const tsMs = Number(ts) > 1e12 ? Number(ts) : Number(ts) * 1000;
  if (!Number.isFinite(tsMs) || Math.abs((opts.nowMs ?? Date.now()) - tsMs) > 10 * 60 * 1000) return false;
  const manifest = `id:${dataId.toLowerCase()};request-id:${requestId};ts:${ts};`;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = hex(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(manifest)));
  return timingSafeEqual(sig, v1.toLowerCase());
}

/** Origens permitidas para CORS (SITE_URL, separadas por vírgula). */
export function corsHeaders(origin: string | null, allowed: string[]): Record<string, string> {
  const ok = origin && allowed.includes(origin) ? origin : allowed[0] ?? "";
  return {
    "Access-Control-Allow-Origin": ok,
    "Access-Control-Allow-Headers": "authorization, content-type, x-client-info, apikey",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Vary": "Origin",
  };
}
