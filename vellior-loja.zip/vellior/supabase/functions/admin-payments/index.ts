// Operações financeiras do painel: estado da integração (mascarado), teste de conectividade e reembolso.
import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { corsHeaders, fromCents, toCents } from "../_shared/mp.ts";

const MP_API = "https://api.mercadopago.com";
const allowed = (Deno.env.get("SITE_URL") ?? "").split(",").map((s) => s.trim()).filter(Boolean);
const Body = z.discriminatedUnion("action", [
  z.object({ action: z.literal("status") }),
  z.object({ action: z.literal("test") }),
  z.object({ action: z.literal("refund"), order_id: z.string().uuid(), amount_cents: z.number().int().positive().optional() }),
]);

Deno.serve(async (req) => {
  const cors = corsHeaders(req.headers.get("origin"), allowed);
  const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);
  const correlation = crypto.randomUUID();
  try {
    const url = Deno.env.get("SUPABASE_URL")!;
    const userClient = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: req.headers.get("Authorization") ?? "" } } });
    const { data: u } = await userClient.auth.getUser();
    if (!u?.user) return json({ error: "unauthorized" }, 401);
    const { data: isAdmin } = await userClient.rpc("is_admin");    // papel verificado no banco, não no navegador
    if (isAdmin !== true) return json({ error: "forbidden" }, 403);

    const parsed = Body.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return json({ error: "invalid_request" }, 400);
    const b = parsed.data;
    const token = Deno.env.get("MP_ACCESS_TOKEN");
    const mask = (s?: string) => (s ? `${s.slice(0, 4)}…${s.slice(-4)}` : null);

    if (b.action === "status") {
      return json({
        access_token_configured: !!token, access_token_masked: mask(token),
        webhook_secret_configured: !!Deno.env.get("MP_WEBHOOK_SECRET"),
        environment: (Deno.env.get("MP_ENV") ?? "sandbox"),
        instructions: "Defina MP_ACCESS_TOKEN, MP_WEBHOOK_SECRET e MP_ENV em Supabase > Edge Functions > Secrets.",
      });
    }
    if (!token) return json({ error: "payments_not_configured" }, 503);

    if (b.action === "test") {
      const r = await fetch(`${MP_API}/users/me`, { headers: { Authorization: `Bearer ${token}` } });
      return json({ ok: r.ok, http_status: r.status });
    }

    // refund
    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: pay } = await admin.from("payments").select("id,provider_payment_id,amount_cents,status")
      .eq("order_id", b.order_id).in("status", ["paid", "partially_refunded"]).maybeSingle();
    if (!pay?.provider_payment_id) return json({ error: "no_refundable_payment" }, 404);
    const { data: ord } = await admin.from("orders").select("total_cents,refunded_cents").eq("id", b.order_id).single();
    const amount = b.amount_cents ?? (ord!.total_cents - ord!.refunded_cents);
    if (amount <= 0 || amount > ord!.total_cents - ord!.refunded_cents) return json({ error: "invalid_amount" }, 400);

    const r = await fetch(`${MP_API}/v1/payments/${pay.provider_payment_id}/refunds`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", "X-Idempotency-Key": `refund:${pay.id}:${ord!.refunded_cents}:${amount}` },
      body: JSON.stringify({ amount: fromCents(amount) }),
    });
    if (!r.ok) { console.error(JSON.stringify({ correlation, event: "refund_failed", status: r.status })); return json({ error: "provider_error", correlation }, 502); }
    const total = ord!.refunded_cents + amount;
    const newStatus = total >= ord!.total_cents ? "refunded" : "partially_refunded";
    await admin.rpc("apply_payment_event", {
      p_payment_id: pay.id, p_event_id: `refund:${pay.id}:${total}`, p_new_status: newStatus, p_correlation: correlation,
      p_detail: { source: "admin_refund", actor: u.user.id, amount_cents: amount }, p_refunded_cents: total,
    });
    await admin.from("audit_log").insert({ actor: u.user.id, action: "refund", object_type: "orders", object_id: b.order_id, detail: { amount_cents: amount, correlation } });
    return json({ ok: true, status: newStatus });
  } catch (e) {
    console.error(JSON.stringify({ correlation, event: "admin_payments_error", message: (e as Error).message }));
    return json({ error: "internal", correlation }, 500);
  }
});
