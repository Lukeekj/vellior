// Cria a cobrança no Mercado Pago a partir de um pedido EXISTENTE. O valor vem do banco, nunca do navegador.
// Cartão: o número NUNCA passa por aqui — o frontend tokeniza via SDK oficial (MP.js) e envia apenas o token.
import { createClient } from "npm:@supabase/supabase-js@2";
import { z } from "npm:zod@3";
import { corsHeaders, fromCents, mapApprovedWithRefund } from "../_shared/mp.ts";

const MP_API = "https://api.mercadopago.com";
const allowed = (Deno.env.get("SITE_URL") ?? "").split(",").map((s) => s.trim()).filter(Boolean);

const Body = z.discriminatedUnion("method", [
  z.object({ method: z.literal("pix"), order_id: z.string().uuid() }),
  z.object({
    method: z.literal("credit_card"), order_id: z.string().uuid(),
    card_token: z.string().min(10).max(200), installments: z.number().int().min(1).max(12),
    payment_method_id: z.string().min(2).max(40), issuer_id: z.string().max(20).optional(),
  }),
]);

Deno.serve(async (req) => {
  const cors = corsHeaders(req.headers.get("origin"), allowed);
  const json = (b: unknown, status = 200) =>
    new Response(JSON.stringify(b), { status, headers: { ...cors, "Content-Type": "application/json" } });
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });
  if (req.method !== "POST") return json({ error: "method_not_allowed" }, 405);

  const correlation = crypto.randomUUID();
  try {
    const token = Deno.env.get("MP_ACCESS_TOKEN");
    if (!token) return json({ error: "payments_not_configured", message: "Pagamentos ainda não configurados." }, 503);

    const url = Deno.env.get("SUPABASE_URL")!;
    const authHeader = req.headers.get("Authorization") ?? "";
    const userClient = createClient(url, Deno.env.get("SUPABASE_ANON_KEY")!, { global: { headers: { Authorization: authHeader } } });
    const { data: u } = await userClient.auth.getUser();       // validação de sessão NO SERVIDOR
    if (!u?.user) return json({ error: "unauthorized" }, 401);

    const parsed = Body.safeParse(await req.json().catch(() => null));
    if (!parsed.success) return json({ error: "invalid_request" }, 400);
    const body = parsed.data;

    const admin = createClient(url, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);

    // Pedido precisa ser do usuário (RLS) e estar aguardando pagamento e com reserva válida.
    const { data: order } = await userClient.from("orders")
      .select("id,total_cents,payment_status,reservation_expires_at,number").eq("id", body.order_id).maybeSingle();
    if (!order) return json({ error: "order_not_found" }, 404);
    if (order.payment_status !== "awaiting_payment") return json({ error: "order_not_payable" }, 409);
    if (new Date(order.reservation_expires_at).getTime() < Date.now()) return json({ error: "reservation_expired" }, 409);

    const { data: cfg } = await admin.from("payment_methods_config").select("enabled,max_installments").eq("method", body.method).single();
    if (!cfg?.enabled) return json({ error: "method_disabled" }, 409);
    if (body.method === "credit_card" && body.installments > cfg.max_installments) return json({ error: "invalid_installments" }, 400);

    // Reaproveita pagamento Pix pendente (evita cobrança duplicada em cliques repetidos)
    const { data: existing } = await admin.from("payments").select("id,pix_qr_code,pix_expires_at,status")
      .eq("order_id", order.id).eq("method", body.method).in("status", ["awaiting_payment", "processing"]).maybeSingle();
    if (existing && body.method === "pix" && existing.pix_qr_code) {
      return json({ payment_id: existing.id, status: existing.status, pix_qr_code: existing.pix_qr_code, pix_expires_at: existing.pix_expires_at });
    }

    const env = (Deno.env.get("MP_ENV") ?? "sandbox") === "production" ? "production" : "sandbox";
    const paymentRowId = existing?.id ?? crypto.randomUUID();
    if (!existing) {
      const { error } = await admin.from("payments").insert({
        id: paymentRowId, order_id: order.id, method: body.method, amount_cents: order.total_cents, environment: env,
      });
      if (error) return json({ error: "internal" }, 500);
    }

    const payload: Record<string, unknown> = {
      transaction_amount: fromCents(order.total_cents),
      description: `Pedido VELLIOR #${order.number}`,
      external_reference: paymentRowId,
      payer: { email: u.user.email },
      notification_url: `${url}/functions/v1/mp-webhook`,
    };
    if (body.method === "pix") {
      payload.payment_method_id = "pix";
      payload.date_of_expiration = new Date(Date.now() + 30 * 60 * 1000).toISOString().replace("Z", "-00:00");
    } else {
      payload.token = body.card_token;
      payload.installments = body.installments;
      payload.payment_method_id = body.payment_method_id;
      if (body.issuer_id) payload.issuer_id = body.issuer_id;
    }

    const mpRes = await fetch(`${MP_API}/v1/payments`, {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", "X-Idempotency-Key": paymentRowId },
      body: JSON.stringify(payload),
    });
    const mp = await mpRes.json().catch(() => ({}));
    if (!mpRes.ok) {
      console.error(JSON.stringify({ correlation, event: "mp_create_failed", status: mpRes.status }));
      return json({ error: "provider_error", correlation }, 502);
    }

    const newStatus = mapApprovedWithRefund(mp.status, mp.transaction_amount_refunded ?? 0, mp.transaction_amount ?? 0);
    const qr = mp.point_of_interaction?.transaction_data?.qr_code ?? null;
    await admin.from("payments").update({
      provider_payment_id: String(mp.id), pix_qr_code: qr,
      pix_expires_at: mp.date_of_expiration ?? null,
    }).eq("id", paymentRowId);

    if (newStatus !== "awaiting_payment") {
      await admin.rpc("apply_payment_event", {
        p_payment_id: paymentRowId, p_event_id: `mp:${mp.id}:${mp.status}:create`, p_new_status: newStatus,
        p_correlation: correlation, p_detail: { source: "create", mp_status: mp.status, mp_status_detail: mp.status_detail },
        p_provider_payment_id: String(mp.id),
      });
    }
    return json({ payment_id: paymentRowId, status: newStatus, pix_qr_code: qr, pix_expires_at: mp.date_of_expiration ?? null, correlation });
  } catch (e) {
    console.error(JSON.stringify({ correlation, event: "create_payment_error", message: (e as Error).message }));
    return json({ error: "internal", correlation }, 500);   // sem stack trace ao cliente
  }
});
