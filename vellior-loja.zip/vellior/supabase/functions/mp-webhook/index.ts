// Webhook do Mercado Pago. Nunca confia no corpo: valida assinatura e CONSULTA o pagamento na API oficial.
import { createClient } from "npm:@supabase/supabase-js@2";
import { mapApprovedWithRefund, toCents, verifyMpSignature } from "../_shared/mp.ts";

const MP_API = "https://api.mercadopago.com";

Deno.serve(async (req) => {
  const correlation = crypto.randomUUID();
  const reply = (status: number, body: unknown = { ok: status < 300 }) =>
    new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });
  if (req.method !== "POST") return reply(405);

  const token = Deno.env.get("MP_ACCESS_TOKEN");
  const secret = Deno.env.get("MP_WEBHOOK_SECRET");
  if (!token || !secret) return reply(503, { error: "not_configured" });

  const reqUrl = new URL(req.url);
  const body = await req.json().catch(() => ({}));
  const dataId = reqUrl.searchParams.get("data.id") ?? body?.data?.id?.toString() ?? null;

  const valid = await verifyMpSignature({
    secret, signatureHeader: req.headers.get("x-signature"), requestId: req.headers.get("x-request-id"), dataId,
  });
  if (!valid) {
    console.warn(JSON.stringify({ correlation, event: "webhook_invalid_signature" }));
    return reply(401, { error: "invalid_signature" });
  }
  if ((body?.type ?? reqUrl.searchParams.get("type")) !== "payment") return reply(200);  // ignora outros tipos

  try {
    // Fonte da verdade: consulta direta ao Mercado Pago.
    const r = await fetch(`${MP_API}/v1/payments/${encodeURIComponent(dataId!)}`, { headers: { Authorization: `Bearer ${token}` } });
    if (!r.ok) return reply(502, { error: "provider_lookup_failed" });   // MP reenviará
    const mp = await r.json();

    const admin = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
    const { data: pay } = await admin.from("payments").select("id,amount_cents").eq("id", mp.external_reference).maybeSingle();
    if (!pay) return reply(200);                                       // pagamento desconhecido: ignora
    if (toCents(mp.transaction_amount) !== pay.amount_cents) {         // valor divergente: não aprova
      console.error(JSON.stringify({ correlation, event: "amount_mismatch", payment: pay.id }));
      return reply(200);
    }
    const status = mapApprovedWithRefund(mp.status, mp.transaction_amount_refunded ?? 0, mp.transaction_amount);
    const { data: result, error } = await admin.rpc("apply_payment_event", {
      p_payment_id: pay.id, p_event_id: `mp:${mp.id}:${mp.status}:${mp.date_last_updated}`, p_new_status: status,
      p_correlation: correlation, p_detail: { source: "webhook", mp_status: mp.status, mp_status_detail: mp.status_detail },
      p_provider_payment_id: String(mp.id), p_refunded_cents: toCents(mp.transaction_amount_refunded ?? 0),
    });
    if (error) { console.error(JSON.stringify({ correlation, event: "apply_failed", code: error.code })); return reply(500); }
    return reply(200, { result });
  } catch (e) {
    console.error(JSON.stringify({ correlation, event: "webhook_error", message: (e as Error).message }));
    return reply(500);
  }
});
