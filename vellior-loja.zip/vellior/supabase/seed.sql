-- VELLIOR — dados de DEMONSTRAÇÃO (is_demo = true). Substitua por produtos reais no painel.
-- Não contém avaliações, vendas, materiais ou garantias inventados. Sem imagens: o front usa placeholder.
insert into public.categories (slug, name, description, position, published) values
 ('relogios','Relógios',null,1,true), ('semijoias','Semijoias',null,2,true),
 ('colares-e-correntes','Colares e correntes',null,3,true), ('pulseiras','Pulseiras',null,4,true),
 ('aneis','Anéis',null,5,true), ('brincos','Brincos',null,6,true), ('acessorios','Acessórios',null,7,true)
on conflict (slug) do nothing;

with p as (
  insert into public.products (slug, name, description, category_id, price_cents, sale_price_cents, published, featured, is_demo)
  select v.slug, v.name, 'Produto de demonstração — será substituído por um produto real.', c.id, v.price, v.sale, true, v.feat, true
  from (values
    ('demo-relogio-classico','Relógio Clássico (demonstração)','relogios',49900,null::int,true),
    ('demo-relogio-minimal','Relógio Minimal (demonstração)','relogios',39900,34900,true),
    ('demo-colar-ponto','Colar Ponto de Luz (demonstração)','colares-e-correntes',12900,null,true),
    ('demo-pulseira-elos','Pulseira Elos (demonstração)','pulseiras',15900,null,false),
    ('demo-anel-solitario','Anel Solitário (demonstração)','aneis',11900,9900,false),
    ('demo-brinco-argola','Brinco Argola (demonstração)','brincos',8900,null,true),
    ('demo-conjunto','Conjunto Semijoia (demonstração)','semijoias',19900,null,false),
    ('demo-porta-joias','Porta-joias (demonstração)','acessorios',7900,null,false)
  ) as v(slug, name, cat, price, sale, feat)
  join public.categories c on c.slug = v.cat
  on conflict (slug) do nothing
  returning id, slug
)
insert into public.product_variants (product_id, sku, label, color, stock)
select p.id, upper(p.slug) || '-' || upper(left(x.col, 3)), x.col, x.col, 10
from p cross join (values ('Dourado'), ('Prata')) as x(col);

insert into public.store_settings (key, value, is_public) values
 ('shipping', '{"flat_cents":2490,"free_over_cents":29900}', false)
on conflict (key) do nothing;
-- Métodos de pagamento permanecem DESABILITADOS até configurar credenciais (ver docs/PAGAMENTOS.md).
