# VELLIOR — Relógios, Semijoias e Acessórios
*Elegância em cada detalhe.*

Loja virtual com contas de clientes, compra restrita a usuários autenticados, painel administrativo, pedidos, estoque atômico e pagamentos via Mercado Pago (Pix; cartão no backend).
**Leia `docs/STATUS.md` antes de publicar**: ele diz, sem maquiagem, o que está testado, o que aguarda credenciais e o que ainda não existe.

## Stack
React 18 + Vite + TypeScript · Supabase (PostgreSQL, Auth, Storage, Edge Functions/Deno) · Mercado Pago · zod · vitest.

## Estrutura
```
src/                 loja pública, auth, conta, checkout e painel (/admin)
supabase/migrations  0001 esquema · 0002 RLS/privilégios · 0003 funções transacionais
supabase/functions   create-payment · mp-webhook · admin-payments (status, teste, reembolso)
supabase/seed.sql    produtos de DEMONSTRAÇÃO (is_demo=true)
tests/unit.test.ts   validação, dinheiro, redirect seguro (vitest)
tests/db/            testes de RLS/regras e de concorrência em Postgres real
docs/                STATUS, SEGURANCA, ADMIN, AUTENTICACAO, PAGAMENTOS
```

## Rodar localmente
```bash
npm install
cp .env.example .env        # preencha VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY
npm run dev
npm run build && npm test   # tipos + build + testes unitários
bash tests/db/run.sh        # testes de banco (precisa de PostgreSQL 16 local)
bash tests/db/concurrency.test.sh
```

## Implantar (resumo)
1. Crie um projeto Supabase. Aplique `supabase/migrations/*.sql` em ordem (CLI: `supabase db push`). Opcional: `supabase/seed.sql`.
2. Crie o 1º administrador: `docs/ADMIN.md`.
3. Configure Auth (URLs de redirecionamento, e-mail, Google/Apple): `docs/AUTENTICACAO.md`.
4. Pagamentos: `docs/PAGAMENTOS.md` (secrets do backend + webhook). Deploy: `supabase functions deploy create-payment mp-webhook admin-payments`.
5. Agende `select public.release_expired_reservations();` a cada 5 min (pg_cron: `select cron.schedule('release-reservations','*/5 * * * *','select public.release_expired_reservations()');`).
6. Publique o front (Vercel/Netlify/Lovable). Os cabeçalhos de segurança estão em `vercel.json` e `public/_headers`.
7. Percorra o checklist de `docs/SEGURANCA.md`.

## Regras de ouro do projeto
- Preço, desconto, frete, estoque e status são sempre calculados/validados no banco; o navegador não envia valores.
- Papéis ficam em `user_roles`, sem política de escrita para a API; admin só por processo controlado.
- Nenhum segredo no front; `service_role` e tokens do Mercado Pago só em Edge Functions.
- Pedido só vira "pago" por notificação verificada do provedor, nunca pelo retorno do navegador.
