# VELLIOR Store

Base inicial de e-commerce para relógios, semijoias e acessórios. Interface React + TypeScript + Vite, com Supabase preparado para autenticação, catálogo, contas e painel administrativo.

## O que já existe neste repositório
- Loja responsiva com identidade visual VELLIOR (branco, cinza e grafite).
- Página inicial, catálogo com busca/filtros/ordenação e páginas de produto.
- Sacola persistente no navegador.
- Cadastro e login por e-mail usando Supabase Auth, recuperação de senha e OAuth preparado para Google e Apple.
- Área de cliente que consulta os pedidos da conta.
- Estrutura inicial do painel administrativo com verificação de papel no banco.
- Esquema SQL com RLS para começar a proteger dados.
- Checkout visual explicitamente em modo de demonstração: não cria cobrança nem pedido real.

## O que ainda precisa ser configurado/implementado antes de vender
- Projeto Supabase real, variáveis de ambiente e execução/revisão do SQL.
- Credenciais OAuth de Google e Apple no Supabase e URLs autorizadas.
- Backend de checkout para criar pedidos e cobranças com validação de preço/estoque.
- Integração de pagamento (ex.: Mercado Pago), validação de webhooks e idempotência.
- Integração de frete, etiquetas e rastreamento.
- Formulários completos de cadastro/edição de produtos e gestão de pedidos.
- E-mails transacionais, políticas legais e configuração de domínio.
- Revisão de segurança independente e testes em staging.

**Não use este scaffold para aceitar pagamentos reais sem concluir as integrações e os testes.**

## Rodar localmente
1. Instale Node.js LTS.
2. Copie `.env.example` para `.env.local` e informe `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY`.
3. `npm install`
4. `npm run dev`
5. `npm run build` para verificar compilação.

Sem Supabase configurado, a interface continua visível, mas cadastro/login não funcionam. Não use chave `service_role` em variável `VITE_*`.

## Configurar Supabase
1. Crie um projeto no Supabase.
2. Abra SQL Editor e revise/executa `supabase/schema.sql` em um projeto novo de teste.
3. Em Authentication, configure confirmação de e-mail e URLs autorizadas.
4. Configure Google e Apple seguindo a documentação oficial do Supabase e de cada provedor.
5. Crie uma conta administrativa normal, confirme a identidade e então promova somente o UUID verificado pelo SQL Editor:
   ```sql
   update public.profiles set role = 'admin' where id = 'UUID-VERIFICADO';
   ```
6. Ative MFA para a conta administrativa e não permita promoção de papel por interfaces públicas.

## Deploy
- GitHub: envie o repositório.
- Vercel: importe o repositório e defina `VITE_SUPABASE_URL` e `VITE_SUPABASE_ANON_KEY` em Environment Variables.
- Configure domínio, URLs de OAuth e redirecionamentos após saber o domínio final.

## Pagamentos
O checkout atual é somente visual e intencionalmente não cria pedido real. Implemente uma Edge Function autenticada para validar usuário, produtos, preços, descontos e estoque no servidor; crie pedido pendente e cobrança no provedor; valide webhooks assinados; e atualize status de forma idempotente. Guarde segredos nas Supabase Edge Function Secrets. Nunca confie na tela de retorno do pagamento como prova de aprovação.

## Segurança
Leia `SECURITY.md` e teste RLS com usuários distintos. A chave pública/anon é destinada ao cliente e depende de RLS correto. A chave `service_role` ignora RLS e jamais pode ser enviada ao navegador.
