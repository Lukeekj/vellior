# Checklist de segurança — VELLIOR

Este projeto é uma base de desenvolvimento, não uma certificação de segurança nem uma garantia de invulnerabilidade.

## Antes de produção
- [ ] Criar um projeto Supabase dedicado para staging e outro para produção.
- [ ] Revisar cada policy RLS com contas anon, customer e admin.
- [ ] Confirmar que clientes não conseguem alterar role, preço, estoque, pagamento ou status de pedido.
- [ ] Criar o primeiro administrador por procedimento manual seguro e ativar MFA.
- [ ] Guardar tokens privados somente em secrets do backend.
- [ ] Implementar rate limiting em autenticação, cupons, checkout e endpoints de alto risco.
- [ ] Validar entrada no servidor e limitar tamanho/tipo de uploads.
- [ ] Implementar checkout no backend com validação de preço, frete, cupom e estoque.
- [ ] Validar assinatura/autenticidade de webhooks e processar eventos de forma idempotente.
- [ ] Configurar CSP, HSTS, HTTPS, CORS restrito e cabeçalhos de segurança no host.
- [ ] Configurar logs sem senhas, tokens ou dados completos de pagamento.
- [ ] Configurar backups e testar restauração.
- [ ] Rodar auditoria de dependências, testes de autorização e testes end-to-end.
- [ ] Publicar políticas de privacidade, cookies quando aplicável, termos, entrega e trocas revisadas.
- [ ] Validar obrigações LGPD e requisitos de defesa do consumidor.

## Limitações conhecidas deste scaffold
- O checkout é demonstrativo e não cria pedido nem cobrança real.
- OAuth Google/Apple exige credenciais e configuração do provedor.
- Gestão de produtos/pedidos no admin é parcialmente somente leitura.
- Integração de frete e e-mail não está implementada.
- Rate limiting e monitoramento precisam ser configurados no backend/infraestrutura.
- O SQL deve ser testado e revisado antes de uso em produção.
